package com.scm.seqnogeneration;

import java.net.NetworkInterface;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;
//import org.apache.commons.lang.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;




public class GetNextReferenceNumber 
{

	private static final Logger logger = LoggerFactory.getLogger(GetNextReferenceNumber.class);

	private static AtomicLong numberGenerator = new AtomicLong(0L);

	
	public volatile static List<Sequence> listSequence = Arrays.asList(
			new Sequence("IN", "IT", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "OT", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "ON", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "IN", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "IL", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "OL", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "DC", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "IA", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "ST", 0L, "", 4, new AtomicLong(1L), "Y"),
			new Sequence("IN", "SE", 0L, "", 4, new AtomicLong(1L), "Y")
			);

    
	
	
	
	private static final int NODE_ID_BITS = 10;
	private static final int maxNodeId = (int)(Math.pow(2, NODE_ID_BITS) - 1);
	
	
    public synchronized static String getNext(final String countryCode, final String keyName) throws Exception 
    {
    	Predicate<Sequence> contCountryCode = p -> p.getCountryCode().equals(countryCode);
    	Predicate<Sequence> contkeyName = p -> p.getKeyName().equals(keyName);
    	Predicate<Sequence> cont = contCountryCode.and(contkeyName);
    	Sequence sequence = listSequence.stream().filter(cont).collect(Collectors.toList()).get(0);

    	createNodeId();
    	
    	return getNextSequence(sequence);
    	
    	 
    	
    	
    }
    
    private static String getNextSequence(Sequence sequence) throws Exception
    {
    	Long lockReferenceNo = sequence.getLocReferenceNo();
    	String nextChar;
    	
		if(String.valueOf(lockReferenceNo).length() > sequence.getSeqLenght())
		{
			if((String.valueOf(sequence.getSeqNo()).length() ==  (sequence.getSeqLenght() - sequence.getCharSequence().length())))
			{
				
				if(String.valueOf(sequence.getSeqNo()).equals(padRight(String.valueOf(9), sequence.getSeqLenght() - sequence.getCharSequence().length(), "9")))
				{
					nextChar = getNextChar(sequence.getCharSequence(), sequence.getSeqLenght());
					sequence.setCharSequence(nextChar);
					
					if(sequence.getSeqLenght() == sequence.getCharSequence().length())
					{
						sequence.setSeqNo(0L);
					}
					else
					{
						sequence.setSeqNo(1L);
					}
				}
				else
					sequence.setSeqNo(sequence.getSeqNo()+ 1L);
				
			}
			else
			{
				sequence.setSeqNo(sequence.getSeqNo()+ 1L);
			}
			
		}
		else
		{
			sequence.setSeqNo(lockReferenceNo);
		}

		String result = "";
    	if(sequence.getSeqNo() == 0)
    		result = sequence.getCharSequence();
    	else
    		result = sequence.getCharSequence() + padRight(sequence.getSeqNo(), sequence.getSeqLenght() - sequence.getCharSequence().length(), "0");
    	
    	//logger.info(result);
		/*count++;
		if(count%10000 == 0)
			System.out.println("");
		*/
    	System.out.print(result + ",");
    	return result;
    }
    
    public static String padRight(long seqno, int n, String s ) 
    {
    	String formart = "%0"+ String.valueOf(n) +"d";
    	String result = String.format(formart, seqno);
    	return result;
   }
    public static String padRight(String charec, int length, String str ) 
    {
    	String result="";
    	
    	String temp ="";
    	try
    	{
    		result = (String.format("%" + length + "s", "").replace(" ", String.valueOf(charec)) + str).substring(str.length(), length + str.length());
    	
    	}
    	catch(Exception e)
    	{
    		System.out.println("");
    		System.out.println("Char Seq: "+ charec + " Length: "+ String.valueOf(length) + " String : "+str);
    		System.out.print("Format : "+ String.format("%" + length + "s", "") + " Char Seq + String : " + (String.valueOf(charec) + str));
    		e.printStackTrace();
    	}
    	return result;
   }
    /*public static String padRight(int n, String s ) {
        return String.format("%1$-" + n + "s", s);  
   }

   public static String padLeft(int n, String s) {
       return String.format("%1$" + n + "s", s);  
   }
*/   
    private static String getNextChar(String charSeq, int seqLength) throws Exception
    {
        int iStartChar = 65;
        int iLastChar = 90;
        int iCounter = 0;
        String result = "";
        boolean isValueChanged = true;

        if (seqLength > 0)
        {
            if (charSeq == null || String.valueOf(charSeq).trim().length() == 0 )
                result = result + (char) iStartChar;
            else if (charSeq.equals(padRight("Z", seqLength, String.valueOf( (char) iLastChar))))
                throw new Exception("[SequenceGenerator: Reached the Maximum Limit.]");
            else if (charSeq.length() < seqLength & charSeq.equals(padRight("Z", seqLength, String.valueOf((char) iLastChar) )))
                result = result + String.valueOf((char) iStartChar);
            
            int charSeqLength = charSeq.length()-1;
            for (iCounter = charSeqLength; iCounter >= 0; iCounter--)
            {
                String currentChar = String.valueOf(charSeq. charAt(iCounter));
                int iCurrentCharValue = charSeq. charAt(iCounter);
                if (isValueChanged)
                {
                    if (iCurrentCharValue >= iStartChar & iCurrentCharValue < iLastChar)
                    {
                        result = (char) (iCurrentCharValue + 1) + result;
                        isValueChanged = false;
                    }
                    else if (iCurrentCharValue >= iLastChar)
                    {
                        iCurrentCharValue = iStartChar;
                        result = (char) (iCurrentCharValue) + result;
                        isValueChanged = true;
                    }
                    else if (isValueChanged)
                    {
                        result = (char) (iCurrentCharValue + 1) + result;
                        isValueChanged = false;
                    }
                    else
                    {
                        result = (char) (iCurrentCharValue) + result;
                        isValueChanged = false;
                    }
                }
                else
                    result = (char) (iCurrentCharValue) + result;
            }
        }
        else
            throw new Exception("[SequenceGenerator: Invalid Length of the Sequence.]");
        return result;
    }

    private static int createNodeId() {
        int nodeId;
        try {
            StringBuilder sb = new StringBuilder();
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                byte[] mac = networkInterface.getHardwareAddress();
                if (mac != null) {
                    for(int i = 0; i < mac.length; i++) {
                        sb.append(String.format("%02X", mac[i]));
                    }
                }
            }
            nodeId = sb.toString().hashCode();
        } catch (Exception ex) {
            nodeId = (new SecureRandom().nextInt());
        }

        nodeId = nodeId & maxNodeId;
        return nodeId;
    }
}
 