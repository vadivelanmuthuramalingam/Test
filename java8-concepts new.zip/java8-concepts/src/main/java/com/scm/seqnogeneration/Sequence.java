package com.scm.seqnogeneration;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicLong;

public class Sequence implements Serializable
{

	
	private static final long serialVersionUID = 1L;
	
	private String countryCode;
	private String keyName;
	private Long seqNo;
	private String charSequence = "";
	private int seqLenght;
	private AtomicLong locReferenceNo;
	private String autoReset;
	
	public Sequence(String countryCode, String keyName, Long seqNo, String charSequence, int seqLenght, AtomicLong locReferenceNo, String autoReset)
	{
		System.out.println("Constructer Called");
		this.countryCode = countryCode;
		this.keyName = keyName;
		this.seqNo=seqNo;
		this.charSequence = charSequence;
		this.seqLenght = seqLenght;
		this.locReferenceNo = locReferenceNo;
		this.autoReset = autoReset;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getKeyName() {
		return keyName;
	}
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}
	public Long getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}
	public synchronized String getCharSequence() 
	{
		return charSequence;
	}
	public synchronized void setCharSequence(String charSequence) 
	{
		this.charSequence = charSequence;
	}
	public int getSeqLenght() {
		return seqLenght;
	}
	public void setSeqLenght(int seqLenght) {
		this.seqLenght = seqLenght;
	}
	public synchronized Long getLocReferenceNo() {
		return locReferenceNo.getAndIncrement(); 
	}
	public void setLocReferenceNo(AtomicLong locReferenceNo) {
		this.locReferenceNo = locReferenceNo;
	}
	public String getAutoReset() {
		return autoReset;
	}
	public void setAutoReset(String autoReset) {
		this.autoReset = autoReset;
	}
	
	
}
