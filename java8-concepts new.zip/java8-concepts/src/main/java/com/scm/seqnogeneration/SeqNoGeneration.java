package com.scm.seqnogeneration;

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

@Service
public class SeqNoGeneration {

	public static void main(String[] args) throws Exception 
	{
		long startTime = System.currentTimeMillis();
		System.out.println(startTime);
		
		
		//String input = "AZaz";
		//System.out.println(input.chars().boxed().collect(Collectors.toList()));
		
		
		//GetNextReferenceNumber.getNext("IN", "IT");
		//GetNextReferenceNumber.getNext("IN", "IT");
		//GetNextReferenceNumber.getNext("IN", "IT");
		//GetNextReferenceNumber.getNext("IN", "IT");
		
		GenerateReference generateReference = new GenerateReference() ;
		
		for(int i=0;i<=1;i++)
		{
			
			generateReference.getReferenceNo();
		}	
		/*
		System.out.println("Count : "+ GetNextReferenceNumber.count);
		
		
		IntStream.range(0, 40000).parallel().forEach((i) ->  
			{
				generateReference.getReferenceNo() ;	
			}
		);
		
		*/
		
		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;

		System.out.println("Thread Name : " + Thread.currentThread().getName().toString() + " Eval Time :  " + String.valueOf(elapsedTime)  );
	}
	
	
	static class GenerateReference implements IRefereNo
	{

		@Override
		public final String getReferenceNo()  
		{
			try
			{
				return GetNextReferenceNumber.getNext("IN", "IT");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			return "";
		}
		
	}

}

interface IRefereNo
{
	String getReferenceNo();
}

