package com.scm.seqnogeneration;

public class GamePrograme 
{

	
	public static void main(String []args)
	{
		Game game = new Game();
		game.startWar();
		
	}
}


class Game
{
	private int []langaburuMaxStrenght = {100, 50, 10, 5};
	private int []falicorniaMaxStregth = {300, 20, 40, 20};
	
	private int []langaburuStrenght = {0, 0, 0, 0};
	private int []falicorniaStregth = {0, 0, 0, 0};
	
	private int []adjusReq = {0, 0, 0, 0};
	//private int []langaburubalnceStrenght = {0, 0, 0, 0};
	
	public void startWar()
	{
		falicorniaStregth[0] = 100;
		falicorniaStregth[1] = 101;
		falicorniaStregth[2] = 20;
		falicorniaStregth[3] = 5;
		
		
		falicorniaStregth[0] = 150;
		falicorniaStregth[1] = 96;
		falicorniaStregth[2] = 26;
		falicorniaStregth[3] = 8;
		
		
		
		System.out.println("*********************Falicornia Strength*****************");
		printValues(falicorniaStregth);
		
		loadDataToStraightMatch();
		
		System.out.println("*********************Langaburu Strength*****************");
		printValues(langaburuStrenght);
		
		
		System.out.println("*********************Langaburu Balance Strength*****************");
		printValues(langaburuMaxStrenght);
		
		System.out.println("*********************Langaburu Adjustant Required*****************");
		printValues(adjusReq);
		
		if(!winningStatus())
		{
			findAdjustand();
		}
		
		System.out.println("----------------------Langaburu Balance Strength---------------");
		printValues(langaburuStrenght);
		System.out.println("*********************Langaburu Adjustant Required*****************");
		printValues(adjusReq);
	}
	
	private void findAdjustand()
	{
		
		for(int i =0; i<=3; i++)
		{
			if(adjusReq[i] > 0)
			{
				if(i==0)
				{
					if(langaburuMaxStrenght[i+1]>0)
					{
						double reqStrenght =  adjusReq[i] / 2;
						if(String.valueOf(reqStrenght).contains(".5") )
							reqStrenght = reqStrenght + .5;

						reqStrenght = reqStrenght * 2;
						fillStrengthForAdj(reqStrenght, i,i+1);
					}
				}
				else if(i==3)
				{
					if(langaburuMaxStrenght[i-1]>1)
					{
						double reqStrenght =  adjusReq[i] / 2;
						if(String.valueOf(reqStrenght).contains(".5") )
							reqStrenght = reqStrenght + .5;

						
						reqStrenght = reqStrenght * 2;
						fillStrengthForAdj(reqStrenght, i,i-1);
					}
				}
				else
				{
					if(langaburuMaxStrenght[i-1]>0 || langaburuMaxStrenght[i+1]>0)
					{
						double reqStrenght =  ((double) adjusReq[i]) / 2;
						if(String.valueOf(reqStrenght).contains(".5") )
							reqStrenght = reqStrenght + .5;

						
						reqStrenght = reqStrenght * 2;
						if(reqStrenght >= langaburuMaxStrenght[i-1])
						{
							reqStrenght = langaburuMaxStrenght[i-1];
							adjusReq[i] = adjusReq[i] - ((int) reqStrenght /2);
						}
						fillStrengthForAdj(reqStrenght, i-1,i-1);
						
						
						
						
						reqStrenght =  adjusReq[i] / 2;
						if(String.valueOf(reqStrenght).contains(".5") )
							reqStrenght = reqStrenght + .5;

					
						fillStrengthForAdj(reqStrenght, i+1,i+1);
					}
				}
			}
		}
	}
	private void loadDataToStraightMatch()
	{
		double findStrenght = 0;
		
		for(int i=0;i<=3;i++)
		{
			findStrenght=(double) falicorniaStregth[i]/2;
			fillStrength(findStrenght, i);
		}
		
	}

	private boolean winningStatus()
	{
		boolean result = true;
		
		for(int i=0;i<=3;i++)
		{
			if(adjusReq[i] > 0)
			{
				result = false;
				break;
			}
		}
		
		return result;
	}
	private void fillStrength(double findStrenght, int position)
	{
		if(findStrenght <= langaburuMaxStrenght[position])
		{
			if(String.valueOf(findStrenght).contains(".5") )
				findStrenght = findStrenght + .5;
			langaburuStrenght[position] = (int) findStrenght;
			langaburuMaxStrenght[position] = langaburuMaxStrenght[position] - (int) findStrenght;
		}
		else
		{
			if(String.valueOf(findStrenght).contains(".5") )
				findStrenght = findStrenght + .5;
			
			langaburuStrenght[position] = langaburuMaxStrenght[position];
			adjusReq[position] = (int) findStrenght - langaburuMaxStrenght[position];
		}
	}
	
	
	private void fillStrengthForAdj(double findStrenght, int addPosition, int removePosition)
	{
		if(findStrenght <= langaburuMaxStrenght[removePosition])
		{
			if(String.valueOf(findStrenght).contains(".5") )
				findStrenght = findStrenght + .5;
			langaburuStrenght[addPosition] = langaburuStrenght[addPosition] + (int) findStrenght;
			langaburuMaxStrenght[removePosition] = langaburuMaxStrenght[removePosition] - (int) findStrenght;
		}
		else
		{
			if(String.valueOf(findStrenght).contains(".5") )
				findStrenght = findStrenght + .5;
			
			langaburuStrenght[addPosition] = langaburuStrenght[addPosition] + (int) findStrenght;
			
			adjusReq[addPosition] = 1;
		}
	}
	

	private void printValues(int []arr)
	{
		String result ="";
		for (int i=0;i<=3;i++)
		{
			result = result.concat(" " + String.valueOf(arr[i]));
		}
		System.out.println(result);
	}
		
}
