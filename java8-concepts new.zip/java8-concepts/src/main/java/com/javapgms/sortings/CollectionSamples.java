package com.javapgms.sortings;

import java.util.ArrayList;
import java.util.Collections;

public class CollectionSamples {
	
	public static void main(String[] args)
	{
		ArrayList<String> al = new ArrayList<>();
		al.add("Vadivelan");
		al.add("Muthuramalingam");
		al.add("Aladipatti");
		
		System.out.println("--------------Before Sorting--------------------");
		System.out.println(al);
		
		System.out.println("--------------After Sorting--------------------");
		Collections.sort(al);
		System.out.println(al);
		
		
		int result = Collections.binarySearch(al, "Vadivelan");
		
		System.out.println(result);
	}

}
