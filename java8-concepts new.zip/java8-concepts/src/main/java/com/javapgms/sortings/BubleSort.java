package com.javapgms.sortings;

import java.util.Arrays;

public class BubleSort 
{

	public static void main(String[] args)
	{
		int[] arr = {5, 1, 4, 2, 8}; 
		
		BubleSort obj = new BubleSort();
		obj.startBubleSort(arr);
	}
	
	private void startBubleSort(int[] arr)
	{
		
		for(int i=0;i<arr.length - 1;i++)
		{
			for(int k=0;k<arr.length - 1;k++)
			{
				if(arr[k]>arr[k+1])
				{
					int temp = arr[k];
					arr[k] = arr[k+1];
					arr[k+1] = temp;
				}
			}
		}
		
		System.out.println(Arrays.toString(arr));
	}
}
