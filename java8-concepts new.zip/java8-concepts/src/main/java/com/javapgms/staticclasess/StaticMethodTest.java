package com.javapgms.staticclasess;

public class StaticMethodTest 
{
	static int count =0;
	static int test =0;
	public void print()
	{
		count = count+ 10;
		System.out.println(String.valueOf(count));
	}
	
	public static void printStatic()
	{
		test = test+ 10;
		count = count + 10;
		
		System.out.println(String.valueOf(test));
	}
	
	public static void printStatic2()
	{
		int k = 0;
		k =k +10;
		System.out.println(String.valueOf(k));
	}
}
