package com.javapgms.staticclasess;

public class Test2 {

}
