package com.javapgms.staticclasess;

public class CompareStatementPreparedStatement {

	/*The Prepared Statement is a slightly more powerful version of a Statement, and should always be at least as quick and 
	 * easy to handle as a Statement. The Prepared Statement may be parametrized

	Most relational databases handles a JDBC / SQL query in four steps:

	Parse the incoming SQL query
	Compile the SQL query
	Plan/optimize the data acquisition path
	Execute the optimized query / acquire and return data
	
	
	A Statement will always proceed through the four steps above for each SQL query sent to the database. 
	A Prepared Statement pre-executes steps (1) - (3) in the execution process above. 
	Thus, when creating a Prepared Statement some pre-optimization is performed immediately. 
	The effect is to lessen the load on the database engine at execution time.
	
	
	
	1) Statement is used for static queries like DDLs i.e. create,drop,alter and prepareStatement is used for dynamic queries i.e. DML query.
	2) In Statement, the query is not precompiled while in prepareStatement query is precompiled, because of this prepareStatement is time efficient.
	3) prepareStatement takes argument at the time of creation while Statement does not take arguments. For Example if you want to create table and insert element then :: Create table (static) by using Statement and Insert element (dynamic)by using prepareStatement.
	
	
	Some of the benefits of PreparedStatement over Statement are:

	1) PreparedStatement helps us in preventing SQL injection attacks because it automatically escapes the special characters.
	2) PreparedStatement allows us to execute dynamic queries with parameter inputs.
	3) PreparedStatement provides different types of setter methods to set the input parameters for the query.
	4) PreparedStatement is faster than Statement. It becomes more visible when we reuse the PreparedStatement or use it’s batch processing methods for executing multiple queries.
	5) PreparedStatement helps us in writing object Oriented code with setter methods whereas with Statement we have to use String Concatenation to create the query. If there are multiple parameters to set, writing Query using String concatenation looks very ugly and error prone.
*/	
	
}
