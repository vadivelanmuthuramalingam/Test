package com.javapgms.streamworkflow;

import java.util.*;
import java.util.stream.Stream;


public class Test01 
{

	/*
	 * Refer --> https://winterbe.com/posts/2014/07/31/java8-stream-tutorial-examples/
	 * 
	 * In functional programming, a monad is a structure that represents computations defined as sequences of steps. 
	 * A type with a monad structure defines what it means to chain operations, or nest functions of that type together.
	 * 
	 * 
	 * Stream operations are either intermediate or terminal. 
	 * Intermediate operations return a stream so we can chain multiple intermediate operations without using semicolons
	 * 
	 * 
	 * 
	 */
	
	public static void main(String[] args)
	{
		List<String> myList =
			    Arrays.asList("a1", "a2", "b1", "c2", "c1");

		//Stream Work Flow
			myList
			    .stream()
			    .filter(s -> s.startsWith("c"))
			    .map(String::toUpperCase)
			    .sorted()
			    .forEach(System.out::println);
			
		
		/*
		 * 
		 * Streams can be created from various data sources, especially collections. 
		 * Lists and Sets support new methods stream() and parallelStream() to either create a sequential or a parallel stream. 
		 * 	
		 */
		Arrays.asList("a1", "a2", "a3")
	    .stream()
	    .findFirst()
	    .ifPresent(System.out::println);	

		
		/*
		 * create a stream from a bunch of object references
		 * 
		 */
		
		Stream.of("a1", "a2", "a3")
		    .findFirst()
		    .ifPresent(System.out::println);
		
		
		Stream.of("d2", "a2", "b1", "b3", "c")
		    .map(s -> {
		        System.out.println("map: " + s);
		        return s.toUpperCase();
		    })
		    .anyMatch(s -> {
		        System.out.println("anyMatch: " + s);
		        return s.startsWith("A");
		    });
		
		/*
		 * The operation anyMatch returns true as soon as the predicate applies to the given input element. 
		 * This is true for the second element passed "A2". Due to the vertical execution of the stream chain, map has only to be executed twice in 
		 * this case. So instead of mapping all elements of the stream, map will be called as few as possible.
		 */
		
		
	}
}
