package com.javapgms.interfaces;

import java.util.Arrays;
import java.util.Comparator;

public class Comparator_Comparable_Diff_03 
{

	public static void main(String[] args)
	{
		Employee3[] empArr = new Employee3[7];
	    empArr[0] = new Employee3(10, "Velan", 25, 1000);
	    empArr[1] = new Employee3(20, "Vadivelan", 29, 8000);
	    empArr[2] = new Employee3(5, "Muthu", 35, 3000);
	    empArr[3] = new Employee3(1, "Ramalingam", 32, 9000);
	    empArr[4] = new Employee3(2, "Senthi", 38, 4000);
	    empArr[5] = new Employee3(3, "Karthik", 23, 5000);
	    empArr[6] = new Employee3(4, "Balu", 39, 7000);

	    System.out.print("Before Sort: ");
	    System.out.println(Arrays.toString(empArr));
	    System.out.println();
	    System.out.println();
	    System.out.println();
	    System.out.println();
        //sort employees array using Comparator by Salary
	    Arrays.sort(empArr, Employee3.SalaryComparator);
	    System.out.println("Employees list sorted by Salary:\n"+Arrays.toString(empArr));

	    //sort employees array using Comparator by Age
	    Arrays.sort(empArr, Employee3.AgeComparator);
	    System.out.println("Employees list sorted by Age:\n"+Arrays.toString(empArr));

	    //sort employees array using Comparator by Name
	    Arrays.sort(empArr, Employee3.NameComparator);
	    System.out.println("Employees list sorted by Name:\n"+Arrays.toString(empArr));
	
	}
}



class Employee3 {

    private int id;
    private String name;
    private int age;
    private long salary;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public long getSalary() {
        return salary;
    }

    public Employee3(int id, String name, int age, int salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

   
    @Override
    //this is required to print the user friendly information about the Employee
    public String toString() {
        return "[id=" + this.id + ", name=" + this.name + ", age=" + this.age + ", salary=" +
                this.salary + "]";
    }

    
    /**
     * Comparator to sort employees list or array in order of Salary
     */
    public static Comparator<Employee3> SalaryComparator = new Comparator<Employee3>() {

        @Override
        public int compare(Employee3 e1, Employee3 e2) 
        {
        	System.out.println("-----------------------------------------------------------------");
        	System.out.println(e1);
        	System.out.println(e2);
        	System.out.println("-----------------------------------------------------------------");
        	System.out.println();
            return (int) (e1.getSalary() - e2.getSalary());
        }
    };
    
    
    /**
     * Comparator to sort employees list or array in order of Age
     */
    public static Comparator<Employee3> AgeComparator = new Comparator<Employee3>() {

        @Override
        public int compare(Employee3 e1, Employee3 e2) {
            return e1.getAge() - e2.getAge();
        }
    };

    /**
     * Comparator to sort employees list or array in order of Name
     */
    public static Comparator<Employee3> NameComparator = new Comparator<Employee3>() {

        @Override
        public int compare(Employee3 e1, Employee3 e2) {
            return e1.getName().compareTo(e2.getName());
        }
    };
}