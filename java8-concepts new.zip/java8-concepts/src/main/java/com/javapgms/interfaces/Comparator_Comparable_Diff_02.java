package com.javapgms.interfaces;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class Comparator_Comparable_Diff_02 
{

	public static void main(String[] args)
	{
		Employee1[] empArr = new Employee1[7];
	    empArr[0] = new Employee1(10, "Velan", 25, 1000);
	    empArr[1] = new Employee1(20, "Vadivelan", 29, 8000);
	    empArr[2] = new Employee1(5, "Muthu", 35, 3000);
	    empArr[3] = new Employee1(1, "Ramalingam", 32, 9000);
	    empArr[4] = new Employee1(2, "Senthi", 38, 4000);
	    empArr[5] = new Employee1(3, "Karthik", 23, 5000);
	    empArr[6] = new Employee1(4, "Balu", 39, 7000);
	    
	    
	    
	    System.out.print("Before Sort: ");
	    System.out.println(Arrays.toString(empArr));
	    
	    Arrays.sort(empArr); //Using quick sorting to arrange the order. https://www.geeksforgeeks.org/quick-sort/

	    
	    System.out.println(Arrays.toString(empArr));
	    
	    //Refer 03 version to understand the comparator
	}
}



class Employee1 implements Comparable<Employee1> {

    private int id;
    private String name;
    private int age;
    private long salary;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public long getSalary() {
        return salary;
    }

    public Employee1(int id, String name, int age, int salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    @Override
    public int compareTo(Employee1 emp) {
        //let's sort the employee based on id in ascending order
        //returns a negative integer, zero, or a positive integer as this employee id
        //is less than, equal to, or greater than the specified object.
    	System.out.println("-----------------------------------------------------------------");
    	System.out.println("ID : "+ String.valueOf(this.id));
    	System.out.println(emp);
    	System.out.println("-----------------------------------------------------------------");
    	System.out.println();
        
        return (this.id - emp.id);
    }

    @Override
    //this is required to print the user friendly information about the Employee
    public String toString() {
        return "[id=" + this.id + ", name=" + this.name + ", age=" + this.age + ", salary=" +
                this.salary + "]";
    }

}