package com.javapgms.interfaces.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class Test 
{

	//@Autowired
	//private Interface1 interface1;
	
	public void test()
	{
		//interface1.print();
	}
	
}
