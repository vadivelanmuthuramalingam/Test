package com.javapgms.interfaces.impl;

import org.springframework.stereotype.Service;



@Service
public class ClassInterface1 implements Interface1
{

	
	public void print() {
		System.out.println("ClassInterface1 --> Print Called." );
		
	}
	

}



