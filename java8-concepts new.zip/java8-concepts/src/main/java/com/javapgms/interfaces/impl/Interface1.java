package com.javapgms.interfaces.impl;

public interface Interface1 
{

	void print() ;
}
