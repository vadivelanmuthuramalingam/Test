package com.javapgms.interfaces.impl;

import org.springframework.stereotype.Service;



@Service
public class ClassIntreface2 implements Interface1 
{

	//@Override
	public void print() {
		System.out.println("ClassIntreface2 --> Print");
		
	}

}
