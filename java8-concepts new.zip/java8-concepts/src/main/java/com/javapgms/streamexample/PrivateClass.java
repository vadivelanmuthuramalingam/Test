package com.javapgms.streamexample;

public class PrivateClass 
{

	private class test2
	{
		public void print()
		{
			System.out.println("Class test2 - Print");
		}
	}
}
