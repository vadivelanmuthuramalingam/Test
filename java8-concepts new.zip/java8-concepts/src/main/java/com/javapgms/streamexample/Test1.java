package com.javapgms.streamexample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;
import java.util.stream.Stream;

class Test1 {

	private static List<String> lstName = populateList();
	private static Map<String, String> mapDept = populateMap(); 
	public static void main(String[] args) {

		PrivateClass obj = new PrivateClass();
		
		System.out.println("************ Stream From List ******************");
		lstName.stream().forEach(x -> System.out.println(x.toString()));
		System.out.println("************ Obtain Stream from Map using entryset ******************");
		mapDept.entrySet().stream().forEach(x -> System.out.println(x.toString()));
		System.out.println("************ Obtain Stream from Map using keyset ******************");
		mapDept.keySet().stream().forEach(x -> System.out.println(x.toString()));
		System.out.println("************ Obtain Stream from Map using valueset ******************");
		mapDept.values().stream().forEach(x -> System.out.println(x.toString()));

		System.out.println("************ Obtain Stream from Function Generate******************");
		Stream.iterate(0,  i -> i+1).limit(20).forEach(p -> System.out.println(p));
		System.out.println("************ Obtain Stream from Function Bilder******************");
		Stream.builder().add("One").add("Two").add("Three").build().forEach(num -> System.out.println(num));
		
		System.out.println("************ Obtain Stream from another stream******************");
		lstName.stream().distinct().limit(1).sorted().forEach(p -> System.out.println(p));
		
		System.out.println("************ another stream******************");
		IntStream.range(0, 10).forEach(p -> System.out.println(p));
		
		System.out.println("************ another stream******************");
		IntStream.range(0, 10).skip(5). forEach(p -> System.out.println(p));
		
		Stream.of("Velan","Muthu", "Test").sorted().findFirst().ifPresent(p -> System.out.println(p));
		
	}
	
	private static List<String> populateList()
	{
		List<String> list = new ArrayList<>();
		list.add("Vadivelan");
		list.add("Muthuramalingam");
		list.add("Muthuramalingam");
		
		return list;
	}
	
	private static Map<String, String> populateMap() 
	{
		Map<String, String> map = new HashMap<>();
		map.put("Vadivelan", "CSE");
		map.put("Muthuramalingam", "EEE");
		return map;
	}

}
