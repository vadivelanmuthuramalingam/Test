package com.javapgms.lampdaex;

public interface IHelloWord 
{

	void print ();
}
