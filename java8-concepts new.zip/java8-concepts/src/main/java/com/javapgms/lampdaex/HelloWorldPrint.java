package com.javapgms.lampdaex;

public class HelloWorldPrint implements IHelloWord
{

	@Override
	public void print() 
	{
		
		System.out.println("Hello Word!!!");
	}
	

}
