package com.javapgms.lampdaex;

import java.io.FileNotFoundException;
import java.util.function.Function;

//https://www.infoq.com/articles/Java-8-Lambdas-A-Peek-Under-the-Hood


//Refer the above one for Work Flow and real advantage of Lamda 
public class MainClass 
{

	private void print()
	{
		System.out.println("Print Hello World");
	}
	///Behaviour Design Pattern
	//1) Stratagy Design Pattern
	//2) Observer Design Pattern  --> Define a one-to-many dependency between objects so that when one object changes state, all its dependents are notified and updated automatically.
	
	private void print(IHelloWord helloWorldPrint)
	{
		helloWorldPrint.print();
	}
	public static void main(String[] args) 
	{
		
		MainClass mainClass = new MainClass();
		mainClass.print(); // Here the pblm is u cant predefine the behaviors inside the print method. below codes to cover the behaviours
		
		HelloWorldPrint helloWorldPrint = new HelloWorldPrint(); 
		//IHelloWord helloWorldPrint = new HelloWorldPrint(); //crating a specific instance of Hellowoeldprinf for IhelloWord
		
		mainClass.print(helloWorldPrint); //passing behaviour and execute the behaviour
		
		//passing action and execute the action
		
		//inline values examble
		//String name= "vadivelan";
		//double pi=3.14
		
		//can we assign a block of code is variable , assiggn the method itself variable
		//create a block of code by using methods in java 7
		
		
		//lampda will idendify the return type based on the return message
		//take the methods remove the modifiers, method name and return type not required
		//currly brase required when multiple lines in block
		//(int a) is emmbed arguments
	
		mainClass.print(() -> System.out.println("Print Helloworld by Lampda"));
		
		IHelloWord helloWord = () -> System.out.println("Print Helloworld by Lampda 222");
		helloWord.print();
		
		
		//Anonimous class - java7 features
		
		IHelloWord heloword = new IHelloWord() {
			
			@Override
			public void print() {
				System.out.println("Annonious Class Greeting");
				
			}
		};
		
		heloword.print();
		
		mainClass.print(heloword);
		
		//Refer the we site for mode details
		//https://www.infoq.com/articles/Java-8-Lambdas-A-Peek-Under-the-Hood
		//JVM it having a code cache
		IHelloWord heloword_Test_ToUnderstatndTheFlow = new IHelloWord() {
			
			@Override
			public void print() {
				System.out.println("Annonious Class Greeting");
				
			}
		};
		
	}
	
	
	
}
