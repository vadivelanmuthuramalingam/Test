package com.javapgms.classes;

public class FinalClass {
	public static void main(String[] args)
	{
		FinalClass1 obj = new FinalClass1();
		obj.print();
				
	}

}


final class FinalClass1 //have to create a object/instance to access the public var/methods 
{
	public void print()
	{
		System.out.print("FinalClass1 -> print");
	}
}

class InheritFinalClass //extends FinalClass1 --> throws compile time error, final class cant be extented
{
	
}
