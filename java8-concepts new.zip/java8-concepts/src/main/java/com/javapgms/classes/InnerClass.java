package com.javapgms.classes;

import com.javapgms.classes.TestInnerClass.Class2;

public class InnerClass
{

	public static void main(String []args)
	{
		TestInnerClass testInnerClass = new TestInnerClass();
		
		TestInnerClass.Class2 class2 = testInnerClass.new Class2();
		
		
		
	}
	
	
}

class TestInnerClass
{
	private String name ="Vadivelan";
	
	TestInnerClass()
	{
		System.out.println("TestInnerClass - Constructor Called.");
	}
	
	public class Class2
	{
		Class2()
		{
			
			System.out.println("Class2 - Constructor Called.");
			System.out.println("Name: " + name.toString());
		}
	}
}
