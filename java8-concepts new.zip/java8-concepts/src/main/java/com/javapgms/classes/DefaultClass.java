package com.javapgms.classes;

public class DefaultClass {

	public static void main(String[] args)
	{
		//com.javapgms.abstractsamples.CheckDefaultClass --> Class is not vissible outside package
		
	}
	
}
