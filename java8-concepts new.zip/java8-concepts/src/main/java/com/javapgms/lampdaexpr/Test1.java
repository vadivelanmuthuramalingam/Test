package com.javapgms.lampdaexpr;

//Refer https://www.infoq.com/articles/Java-8-Lambdas-A-Peek-Under-the-Hood
public class Test1 
{
	//Enables functionala pgm
	//readable and concise code (elimiate unnecesary code)
	//easier to use API and librares
	//enable parallel processing
	
	
	
	//Funcation programing - better code, readable code, and maintanable code
	
	
	//problem in java 7
	
	
	public void printTest()
	{
		Runnable r1 = () -> System.out.println("My Runnable");
		r1.run();
		
		
		int a = 5; 
		  
        // lambda expression to define the calculate method 
        Square s = (int x)->x*x; 
  
        // parameter passed and return type must be 
        // same as defined in the prototype 
        int ans = s.calculate(a); 
        System.out.println(ans); 
	}

}

@FunctionalInterface
interface Square 
{ 
    int calculate(int x); 
} 