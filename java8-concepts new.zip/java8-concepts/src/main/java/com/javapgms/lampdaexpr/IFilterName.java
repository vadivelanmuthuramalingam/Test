package com.javapgms.lampdaexpr;

public interface IFilterName {
	boolean test(Student student);
}
