package com.javapgms.lampdaexpr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import ch.qos.logback.core.joran.conditional.Condition;

public class TestCollectionsInJava7 
{

	public static void main(String[] args)
	{
		List<Student> lstStudent = Arrays.asList(new Student("Vadvivelan","1"),
				new Student("Mohan","2"),
				new Student("Senthil","3"),
				new Student("Vetrivelan","4"));
		
		
		//Short List by name in java 7
		
		Collections.sort(lstStudent, new Comparator<Student>() {

			@Override
			public int compare(Student s1, Student s2) {
				return s1.getName().compareToIgnoreCase(s2.getName());
			}
		});
		
		printAllSudentDetails(lstStudent);
		printNameStartWithV_1(lstStudent);
		
		printNameStartWithV_2(lstStudent, new IFilterName() {
			
			@Override
			public boolean test(Student student) {
				return student.getName().startsWith("V");
			}
		}); 		
	}
	
	private static void printAllSudentDetails(List<Student> lstStudent)
	{
		for(Student std: lstStudent)
			System.out.println(std.getName().concat("  ID: ").concat(std.getId()) );
	}
	
	private static void printNameStartWithV_1(List<Student> lstStudent)
	{
		for(Student std: lstStudent)
			if(std.getName().startsWith("V")) System.out.println("printNameStartWithV_1 : " + std.getName().concat("  ID: ").concat(std.getId()) );
	}
	private static void printNameStartWithV_2(List<Student> lstStudent, IFilterName filterName)
	{
		for(Student std: lstStudent)
			if(filterName.test(std)) System.out.println("printNameStartWithV_2 : " + std.getName().concat("  ID: ").concat(std.getId()) );
	}
	
	
}

