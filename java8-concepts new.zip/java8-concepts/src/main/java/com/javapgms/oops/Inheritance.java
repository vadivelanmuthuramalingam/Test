package com.javapgms.oops;

public class Inheritance {

	public static void main(String[] args) {

		ClassA classA = new ClassB();
		classA.method2();
		classA.method3();

		ClassB classB = new ClassB();
		classB.method2();
		classB.method3();
	}

}


class ClassA
{
	private void method1()
	{
		System.out.println("ClassA --> method1");
	}
	
	public void method2()
	{
		System.out.println("ClassA --> method2");
	}
	
	protected void method3()
	{
		System.out.println("ClassA --> method3");
	}
}

class ClassB extends ClassA
{
	private void method1()
	{
		System.out.println("ClassB --> method1");
	}
	
	public void method2()
	{
		System.out.println("ClassB --> method2");
	}

	@Override
	protected void method3()
	{
		System.out.println("ClassB --> method3");
	}
}