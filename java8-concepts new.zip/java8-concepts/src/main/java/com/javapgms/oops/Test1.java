package com.javapgms.oops;

import org.apache.tomcat.util.buf.B2CConverter;

public class Test1 
{

	public static void main(String[] args)
	{
		A a = new B();
		a.print();
	}
	
	
}



abstract class A
{
	
	void printA()
	{
		System.out.println("Print - A");
	}
	abstract void print();
}

class B extends A
{

	@Override
	void print() {
		
		System.out.println("Print - B");
		
	}
	
	public void printb()
	{
		System.out.println("PrintB -> B");
	}
}