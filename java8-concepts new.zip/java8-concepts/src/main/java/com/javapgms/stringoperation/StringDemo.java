package com.javapgms.stringoperation;

public class StringDemo {
    public static void main(String[] args) 
    {

    	StringBuilder sb = new StringBuilder();
    	sb.append("test");
    	sb.append("Vadivelan Muthuramingam");
    	sb.append("Vadivelan Muthuramingam");
    	
    	System.out.println("Exit................");
    }
}