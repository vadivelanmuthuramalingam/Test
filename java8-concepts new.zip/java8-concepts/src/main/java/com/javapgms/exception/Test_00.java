package com.javapgms.exception;

public class Test_00 
{

	/*
	 * 
	 * 
Checked Exception
	What is Checked Exception in Java Programming language. In simple language: Exception which are checked at Compile time 
	called Checked Exception. Some these are mentioned below. If in your code if some of method throws a checked exception, 
	then the method must either handle the exception or it must specify the exception using throws keyword.
	
			IOException
			SQLException
			DataAccessException
			ClassNotFoundException
			InvocationTargetException
			MalformedURLException
Unchecked Exception
	Unchecked Exception in Java is those Exceptions whose handling is NOT verified during Compile time. 
	These exceptions occurs because of bad programming. The program won’t give a compilation error. 
	All Unchecked exceptions are direct sub classes of RuntimeException class.
	
			NullPointerException
			ArrayIndexOutOfBound
			IllegalArgumentException
			IllegalStateException

Difference between throw and throws in Java
	There are many differences between throw and throws keywords. A list of differences between throw and throws are given below:
	
	No.	throw															   throws
	----------------------------------------------------------------------------------------------------------------------------------
	1)	Java throw keyword is used to explicitly throw an exception.	| Java throws keyword is used to declare an exception.
	2)	Checked exception cannot be propagated using throw only.		| Checked exception can be propagated with throws.
	3)	Throw is followed by an instance.								| Throws is followed by class.
	4)	Throw is used within the method.								| Throws is used with the method signature.
	5)	You cannot throw multiple exceptions.							| You can declare multiple exceptions e.g.
																		| public void method()throws IOException,SQLException.


Difference between final, finally and finalize
	Final  ->	Final is used to apply restrictions on class, method and variable. Final class can't be inherited, 
				final method can't be overridden and final variable value can't be changed.
	Finally ->	Finally is used to place important code, it will be executed whether exception is handled or not.
	Finalize -> Finalize is used to perform clean up processing just before object is garbage collected.
	
	Final is a keyword.	Finally is a block.	Finalize is a method.

	 */
}
