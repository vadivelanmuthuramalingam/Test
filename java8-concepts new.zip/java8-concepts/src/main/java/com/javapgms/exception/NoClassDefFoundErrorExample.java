package com.javapgms.exception;


/*
 * When you compile the above program, two .class files will be generated. One is NoClassDefFoundErrorExample.class and another one is Test.class. 
 * If you remove the Test.class file and run the NoClassDefFoundErrorExample.class file, Java Runtime System will throw NoClassDefFoundError
 */
public class NoClassDefFoundErrorExample {
    private static Test test = new Test();

    public static void main(String[] args) {
            System.out.println("The definition of Test was found!");
    }
}

class Test {
    public Test() {
            System.out.println("A new instance of the Test class was created!");
    }
}
