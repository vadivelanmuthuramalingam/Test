package com.javapgms.exception;

public class TestFinalize 
{

	public void finalize()
	{
		System.out.println("Inside Finalize Method");
	}  
	public static void main(String[] args)
	{  
		TestFinalize f1=new TestFinalize();  
		TestFinalize f2=new TestFinalize();  
		
		System.out.println("Inside Main method");
		f1=null;  
		f2=null;  
		//System.gc();  
	}
}
