package com.javapgms.exception;

import java.io.IOException;

//https://www.javatpoint.com/exception-handling-with-method-overriding
//refer the url for more scenarios

class Parent
{  
	  void msg()
	  {
		  System.out.println("parent");
	  }  
}  
	  
class TestExceptionChild extends Parent
{  
  /*
  //Compile Time Error Check
  void msg() throws IOException
  {  
    System.out.println("TestExceptionChild");  
  }*/ 

	//This is working because ArithmeticException will call during run time only
  void msg()throws ArithmeticException
  {  
	    System.out.println("child");  
  }  
  public static void main(String args[])
  {  
   Parent p=new TestExceptionChild();  
   p.msg();  
  }  
}  
