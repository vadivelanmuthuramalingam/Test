package com.javapgms.exception;

public class Test_01 {

	/*
	 * 
	 * Difference between Checked and Unchecked Exceptions
	1) Checked Exception
	The classes which directly inherit Throwable class except RuntimeException and Error are known as checked exceptions e.g. IOException, SQLException etc. Checked exceptions are checked at compile-time.
	
	2) Unchecked Exception
	The classes which inherit RuntimeException are known as unchecked exceptions e.g. ArithmeticException, NullPointerException, ArrayIndexOutOfBoundsException etc. Unchecked exceptions are not checked at compile-time, but they are checked at runtime.
	
	3) Error
	Error is irrecoverable e.g. OutOfMemoryError, VirtualMachineError, AssertionError etc.
	
	 */
	
	/*
	 * 
	 * Exception Hieararchy
	 * 				Object
	 * 
	 * 				Throwable
	 * 
	 * Exceptions								Error (All Errors are unchecked error, there is no checked erro)
	 * 	- Checked Exception							- OutOf Memory Error
	 *  - UnChecked Exception						- NoClassDefFoundError
	 * 	- IO Exception	(Checked Exception)			- AssertionError
	 * 												- Virtual Machine Error
	 * 
	 * 
	 * Checked Exception			UnCheckedException			IOException
	 * 								- RunTime Exception
	 * 									
	 */
	public static void main(String[] args)
	{
		String s = null;
		try
		{
			s="test 1";
			System.out.println("S value = " + String.valueOf(s));
			try
			{
				
				int k=50;
				
				try
				{
					k=k/0;
					System.out.println(String.valueOf(k));
				}
				//un block the below code and see the behaviours
				/*catch(Exception e)
				{
					System.out.println("");
				}*/
				finally
				{
					System.out.println("Finally in 3rd Block");
					k=0;
				}
				
			}
			catch(Exception e)
			{
				System.out.println("Exception in first block");
			}
			finally
			{
				System.out.println("Finally in 2nd Block");
			}
		}
		finally
		{
			s=null;
			System.out.println("s in Finally: "+ String.valueOf(s));
		}
	}
	
	private static void test1()
	{
		String s="asd";
		
		int i=Integer.parseInt(s); //throws run time error
		
		//finally will not accept with out try
/*		finally
		{
			s= null;
		}
*/	}
}
