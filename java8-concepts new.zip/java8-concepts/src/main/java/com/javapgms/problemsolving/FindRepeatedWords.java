package com.javapgms.problemsolving;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.StringTokenizer;
import java.util.function.Function;
import java.util.stream.Collectors;

import sun.management.MappedMXBeanType;
import sun.security.pkcs11.wrapper.Functions;

public class FindRepeatedWords {

	public static void main(String[] args) 
	{
	
		String line = "hi hello how are you. hi";
		
		List<String> al = Arrays.asList(line.split(" "));
		
		Map<String, Long> map=  al.stream()
			      .filter(Objects::nonNull)
			      .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		
		
		 System.out.println(map);
		 
		 map.clear();
		  al.stream()
		  .forEach(word -> map.merge(word, 1L, (v, n) -> v+1L));
		 
         System.out.println(map);

         System.out.println("------------------Find the maximum repeated values-------------------------");
         Map.Entry<String, Long> e = al.stream()
	      .filter(Objects::nonNull)
	      .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()) ).entrySet()
	      .stream().max(Map.Entry.comparingByValue()).get(); // .getValue();
         
        System.out.println(e);
        
        al.stream()
	      .filter(Objects::nonNull)
	      .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()) );	
        
        
        List<Entry<String, Long>> list =  al.stream()
	      .filter(Objects::nonNull)
	      .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
	      .entrySet().stream().collect(Collectors.toList());
	
        
        /*List<Entry<String, Long>> list_1 = al.stream()
	      .filter(Objects::nonNull)
	      .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
	      .entrySet().stream().collect(Collectors.toList())
	      .sort(new Comparator<Entry<String, Long>>() 
		      {

				@Override
				public int compare(Entry<String, Long> o1, Entry<String, Long> o2) {
					return o2.getValue().compareTo(o1.getValue());
					//return 0;
				}
	    	  	
		      }
	      )
         */
        
        list.sort(new Comparator<Entry<String, Long>>() 
		      {

				@Override
				public int compare(Entry<String, Long> o1, Entry<String, Long> o2) {
					return o1.getValue().compareTo(o2.getValue());
					//return 0;
				}
	    	  	
		      });
        
	
        System.out.println(list.subList(list.size() - 3, list.size()));
	
	
	}
}