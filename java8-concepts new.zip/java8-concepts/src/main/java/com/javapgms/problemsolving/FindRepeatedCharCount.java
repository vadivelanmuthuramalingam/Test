package com.javapgms.problemsolving;

import java.util.*;

import sun.awt.datatransfer.DataTransferer.CharsetComparator;


public class FindRepeatedCharCount {

	public static void main(String[] args) {
		String line = " Hi How are you....";
		
		//List<String> list = Arrays.asList(line.toCharArray().toString());
		
		Map<Character, Long> map = new HashMap<>();
		
		line.chars()
		.forEach (c -> map.merge((char) c, 1L, (v, n) -> v+1L));
		
		System.out.println(map);
	}
}
