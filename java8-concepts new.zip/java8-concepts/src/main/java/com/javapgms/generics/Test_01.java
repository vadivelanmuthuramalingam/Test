package com.javapgms.generics;

import java.util.ArrayList;
import java.util.List;

/*
 * Generics was added in Java 5 to provide compile-time type checking and removing risk of ClassCastException that was 
 * common while working with collection classes. The whole collection framework was re-written to use generics for type-safety. 
 * Let’s see how generics help us using collection classes safely.
 */
public class Test_01 {
	
	public static void main(String[] args)
	{
		List list = new ArrayList();
		list.add("abc");
		list.add(new Integer(5)); //OK

		for(Object obj : list){
			//type casting leading to ClassCastException at runtime
		    String str=(String) obj; 
		    System.out.println(str);
		    System.out.println("");
		}
	}

}
