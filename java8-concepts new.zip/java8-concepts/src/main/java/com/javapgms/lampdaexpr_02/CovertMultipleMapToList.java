package com.javapgms.lampdaexpr_02;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CovertMultipleMapToList {

	public static void main(String[] args)
	{
		Map<Integer, Map<Integer, String>> map = new HashMap<>();
		
		Map<Integer, String> map1 = new HashMap<>();
		map1.put(1, "Name 1");
		map1.put(2, "Name 2");
		map1.put(3, "Name 3");
		
		Map<Integer, String> map2 = new HashMap<>();
		map2.put(4, "Name 4");
		map2.put(5, "Name 5");
		map2.put(6, "Name 6");
		
		
		map.put(1, map1);
		map.put(2, map2);
		
		
		Map<Object, Object> map3 = Stream.concat(map1.entrySet().stream(), map2.entrySet().stream()).collect(Collectors.toMap(x -> x.toString() , x -> x.toString()));
	
		System.out.println("test");
	}
}
