package com.javapgms.lampdaexpr_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ConvertListToMap {

public static void main(String[] args) {
		
		List<Student> student = Arrays.asList(
				new Student("vadvielan", "1"),
				new Student("Vetrivelan", "2"),
				new Student("Muthu", "3")
				);
        
		
		student.stream().collect(Collectors.toMap(Student::getId, Student::getName, (oldValue,newValue) -> oldValue) ); 
		
        System.out.println("\nCompleted.....................");

	}

	private static boolean getValues(List<Student> listValues, Predicate<Student> student)
	{
		for(Student std: listValues)
			if(student.test(std))
				return true;
		
		return false;
	}
}

