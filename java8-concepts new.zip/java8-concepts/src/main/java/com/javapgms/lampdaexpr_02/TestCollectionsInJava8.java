package com.javapgms.lampdaexpr_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import ch.qos.logback.core.joran.conditional.Condition;

public class TestCollectionsInJava8 
{

	public static void main(String[] args)
	{
		List<Student> lstStudent = Arrays.asList(new Student("Vadvivelan","1"),
				new Student("Mohan","2"),
				new Student("Senthil","3"),
				new Student("Vetrivelan","4"));
		
		System.out.println("Print All Names");
		Collections.sort(lstStudent, (s1, s2) -> s1.getName().compareToIgnoreCase(s2.getName()));

		System.out.println("Print All Names");
		printNameStartWithV_2(lstStudent, s -> true, s -> System.out.println(s));
		
		
		//printNameStartWithV_2(lstStudent, p -> true);
		
		System.out.println("Print Names Start With V");
		printNameStartWithV_2(lstStudent, s -> s.getName().startsWith("V"), s -> System.out.println(s.getName()));
	}
	
	/*
	private static void printNameStartWithV_2(List<Student> lstStudent, FilterName filterName)
	{
		for(Student std: lstStudent)
			if(filterName.filter(std)) System.out.println("printNameStartWithV_2 : " + std.getName().concat("  ID: ").concat(std.getId()) );
	}
	*/
	//Apply Predicate samples
	
	private static void printNameStartWithV_2(List<Student> lstStudent, Predicate<Student> filterName, Consumer<Student> consumer)
	{
		for(Student std: lstStudent)
			if(filterName.test(std)) 
				consumer.accept(std);
	}

}
