package com.javapgms.collections.hashmaps;

import java.util.HashMap;
import java.util.Map;

public class HashMap_02 {

	public static void main(String[] args) 
	{
		System.out.println("Map Started.....");
		Map<String, String> map =new HashMap<>();
		
		for(int i=28;i<=999999990;i++)
		{
			map.put(String.valueOf(i), String.valueOf(i));
		}
		
		System.out.println(map);
	}

}
