package com.javapgms.collections;

import java.util.HashMap;

public class Avoid_HashMap_Collision 
{

	public static void main(String[] args)
	{
		HashMap<Student, String> hm = new HashMap<>();
		Student student1 = new Student(1, "Vadivelan");
		Student student2 = new Student(2, "Muthuramalingam");
		Student student3 = new Student(3, "Mohan");
		Student student4 = new Student(4, "Senthil");
		Student student5 = new Student(5, "Balu");
		
		hm.put(student1, "Vadivelan");
		hm.put(student2, "Muthuramalingam");
		hm.put(student3, "Mohan");
		hm.put(student4, "Senthil");
		hm.put(student5, "Balu");
		
		
		System.out.println(hm);
		
		System.out.println(hm.keySet());
		System.out.println(hm.get(student1));
		System.out.print("------------------------------------Exit---------------------------");
	}
}


class Student
{
	int id;
	String name;
	

	
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


	
	@Override
	public int hashCode()
	{
		System.out.println( " ID "+ String.valueOf(id) + " HashCode : " + (id * name.hashCode()));
		return id * name.hashCode();
	}
	
	@Override
    public boolean equals(Object o) {

        if (o == this) return true;
        if (!(o instanceof Student)) {
            return false;
        }

        Student student = (Student) o;

        return student.name.equals(name) ;
        		//&& user.age == age && user.passport.equals(passport);
    }

}