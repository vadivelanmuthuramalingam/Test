package com.javapgms.collections;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class HashMap_vs_HashTable 
{

	/*
	1) Hashtable is synchronized, whereas HashMap is not. This makes HashMap better for non-threaded applications, as unsynchronized 
	Objects typically perform better than synchronized ones.

	2) Hashtable does not allow null keys or values.  HashMap allows one null key and any number of null values.

	3) One of HashMap's subclasses is LinkedHashMap, so in the event that you'd want predictable iteration order 
	(which is insertion order by default), you could easily swap out the HashMap for a  LinkedHashMap. This wouldn't be as easy 
	if you were using Hashtable.
	*/
	
	/*
	 Note: Hashtable has been obselete in Java 1.7 and it is advisable to use ConcurrentMap.

	Synchronization or Thread Safe: 
		This is the most essential difference between two. HashMap is non synchronized and not thread safe. On the other hand, 
		Hashtable is thread safe and synchronized. When to use HashMap? the answer is if your application does not require any 
		multi-threading task, in other words, HashMap is better for non-threading applications. 
		Hashtable should be used in multithreading applications
	
	Null keys and null values: 
		HashMap allows one null key and any number of null values, while Hashtable dose do not allow null keys and null values in the 
		Hashtable object.
	
	Iterating the values: 
		HashMap object values are iterated by using an iterator . Hashtable is the only class other than vector which uses enumerator 
		to iterate the values of Hashtable object.
	
	Fail-fast iterator: 
		The iterator in HashMap is fail-fast iterator while the enumerator for Hashtable is not. According to Oracle Docs, if the 
		Hashtable is structurally modified at any time after the iterator is created in any way except the iterator's remove method, then the iterator will throw ConcurrentModification Exception. Structural modification means adding or removing elements from the Collection object (here HashMap or Hashtable). Thus the enumerations returned by the Hashtable keys and elements methods are not fail fast. We have already explained the difference between iterator and enumeration.
	
	Performance: 
		HashMap is much faster and uses less memory than Hashtable as former is unsynchronized. Unsynchronized objects are often 
		much better in performance in comparison to the synchronized object like Hashtable in the single-threaded environment.
	
	Superclass and Legacy: 
		Hashtable is a subclass of Dictionary class which is now obsolete in JDK 1.7, so, it is not used anymore. It is better off externally synchronizing a HashMap or using a ConcurrentMap implementation (e.g ConcurrentHashMap).HashMap is the subclass of the AbstractMap class. Although Hashtable and HashMap have different superclasses they both are implementations of the "Map" abstract data type.
	 */
	public static void main(String[] args)
	{
		
		HashMap<AmbiguousInteger, Integer> mapK = new HashMap<>();
		// logically equivalent keys
		AmbiguousInteger key1 = new AmbiguousInteger(1),
		                 key2 = new AmbiguousInteger(1),
		                 key3 = new AmbiguousInteger(1);
		mapK.put(key1, 1); // put in value for entry '1'
		mapK.put(key2, 2); // attempt to override value for entry '1'
		System.out.println(mapK.get(key1));
		System.out.println(mapK.get(key2));
		System.out.println(mapK.get(key3));
		
		
		
		Map<String, String> map = new HashMap<>();
		map.put("FB", "value1");
		map.put("Ea", "value2");
		map.put("FVad2", "value3");
		map.put("FVad1", "value3");
		
		System.out.println(map.get("FB") .hashCode() + " " + map.get("FB"));
		System.out.println(map.get("Ea").hashCode() + " " + map.get("Vad2"));
		System.out.println(map.get("FVad2").hashCode() + " " + map.get("Vad2"));
		System.out.println(map.get("FVad1").hashCode() + " " + map.get("Vad2"));
		
		HashMap<String, String> map1 = new HashMap<>();
		map1.put("Vad1", "value1");
		map1.put("Vad2", "value2");
		map1.put("Vad2", "value3");
		
		System.out.println(map1.get("Vad1").hashCode() + " " + map1.get("Vad1"));
		System.out.println(map1.get("Vad2").hashCode() + " " + map1.get("Vad2"));
        
		
		Hashtable<String, String> ht = new Hashtable<>();
		ht.put("Vad1", "value1");
		ht.put("Vad2", "value2");
		ht.put("Vad2", "value3");
		System.out.println(ht.get("Vad1").hashCode() + " " + ht.get("Vad1"));
		System.out.println(ht.get("Vad2").hashCode() + " " + ht.get("Vad2"));
		
	}
}


class AmbiguousInteger {
    private final int value;

    AmbiguousInteger(int value) {
        this.value = value;
    }
    
    @Override
    public int hashCode() {
        return value;
    }
    
    @Override
    public boolean equals(Object obj) {
        return obj instanceof AmbiguousInteger && value == ((AmbiguousInteger) obj).value;
    }
}