package com.javapgms.collections.hashmaps;

import java.util.HashMap;
import java.util.Map;

public class Test_03 {


	public static void main(String[] args)
	{
		Student std1 = new Student(1, "Vadivelan");
		Student std2 = new Student(1, "Karthik");
		Student std3 = new Student(1, "Karthik 1");
		Student std4 = new Student(1, "Vadivelan");
		Student std5 = new Student(2, "Vadivelan");
	
		 int itration = 0;
		
		System.out.println("---------------Sceanarion 1--------------------");
		Map<Student, Integer> map = new HashMap<>();
		
		System.out.println("Adding Data " + String.valueOf(++itration) + " ID : " + String.valueOf(std1.getId()) + " Name: " + String.valueOf(std1.getName()) );
		map.put(std1, 1);
		System.out.println("Adding Data " + String.valueOf(++itration) + " ID : "  + String.valueOf(std2.getId()) + " Name: " + String.valueOf(std2.getName()) );
		map.put(std2, 1);
		System.out.println("Adding Data " + String.valueOf(++itration) + " ID : "  + String.valueOf(std3.getId()) + " Name: " + String.valueOf(std3.getName()) );
		map.put(std3, 1);
		System.out.println("Adding Data " + String.valueOf(++itration) + " ID : " + String.valueOf(std4.getId()) + " Name: " + String.valueOf(std4.getName()) );
		map.put(std4, 1);
		System.out.println("Adding Data " + String.valueOf(++itration) + " ID : "  + String.valueOf(std5.getId()) + " Name: " + String.valueOf(std5.getName()) );
		map.put(std5, 2);
		
		//System.out.println(map);

		map.forEach((k,v) -> System.out.println("Key = " + k + " Value = "+ String.valueOf(v)) ); 
		
		System.out.println("---------------Sceanarion 2--------------------");
		Map<String, Student> map2 = new HashMap<>();
		
		map2.put(std1.getName(), std1);
		map2.put(std2.getName(), std2);
		map2.put(std3.getName(), std3);
		map2.put(std4.getName(), std4);
		map2.put(std5.getName(), std5);

		map2.forEach((k,v) -> System.out.println("Key = " + k + " Value = "+ String.valueOf(v)) ); 
	}
}


class Student
{

	private int id;
	private String name;
	
	
	private static int itration =0; 	
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public int hashCode() {
		return this.id;
	}


	@Override
	public boolean equals(Object obj) 
	{
		itration++;
		
		System.out.print("Itration : "+ String.valueOf(itration) +"  " + this.id + "   " + this.name);
		System.out.print("\t");
		System.out.println(((Student) obj).id + "  " + ((Student) obj).name );
		if (this == obj)
			return true;
		return false;
	}


}