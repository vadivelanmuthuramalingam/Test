package com.javapgms.collections.hashmaps;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;



public class HashMap_05_PutAll 
{

	public static void main(String[] args) 
	{ 
	      
	    // Creating an empty HashMap 
	    HashMap<Integer, String> hash_map = new HashMap<Integer, String>(); 
	  
	    // Mapping string values to int keys  
	    hash_map.put(10, "Geeks"); 
	    hash_map.put(15, "4"); 
	    hash_map.put(20, "Geeks"); 
	    hash_map.put(25, "Welcomes"); 
	    hash_map.put(30, "You"); 
	  
	    // Displaying the HashMap 
	    System.out.println("Initial Mappings are: " + hash_map); 
	  
	    // Creating a new hash map and copying 
	    HashMap<Integer, String> new_hash_map = new HashMap<Integer, String>(); 
	    new_hash_map.putAll(hash_map); 
	    // Displaying the final HashMap 
	    System.out.println("The new map looks like this: " + new_hash_map); 
	    
	    new_hash_map.forEach((k,v) -> hash_map.merge(k, v, (oldVlaue,newValue) -> newValue));
	    
	    System.out.println("The new map looks like this: " + new_hash_map); 
	} 
}
