package com.javapgms.collections.arraylist;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Array_Sort 
{

	public static void main(String[] args)
	{
		Integer[] arr = {1,5,6,9,10,23,15};
		
		System.out.println(Arrays.toString(sortArrayAlgorithmAsc(arr)));
		System.out.println(Arrays.toString(sortArrayAlgorithmDesc(arr)));
		
		Arrays.sort(arr);
		
		System.out.printf("Shorted Array Values : %s", Arrays.toString(arr));
		

		
		List<Integer> list = Arrays.asList(arr);
		Collections.sort(list);
		System.out.println("sorting collection.sort : " + Arrays.toString(list.toArray()));
		Collections.reverse(list);
		System.out.println("sorting collection.reverse : " + Arrays.toString(list.toArray()));
		
		//Integer []arr2 = {1,15,6,9,4,23,17};
		//Integer []arr2 = {4,3,2,10,12,1,5,6};
		Integer []arr2 = {4,10,3,5,1};
		List<Integer> list2 =  Arrays.asList(arr2);
		

		Comparator<Integer> cmp = new Comparator<Integer>() 
		{

			@Override
			public int compare(Integer a, Integer b) 
			{
				
				
				int k = a.compareTo(b);
				System.out.println("Inside Comparator. A = "+ String.valueOf(a) + 
						"    B = "+ String.valueOf(b) + 
						" Compare Result = " + String.valueOf(k) + 
						" Array : "+ Arrays.toString(list2.toArray()));
				return a.compareTo(b);
			}
			
		};
		
		
		System.out.println("Before Sorting Comparator : " + Arrays.toString(list.toArray()));
		Collections.sort(list2, cmp);
		System.out.println("sorting Collections.sort(list, cmp)  : %s" + Arrays.toString(list2.toArray()));
	}
	
	private static Integer[] sortArrayAlgorithmAsc(Integer[] array) { //sort in descending order
	    for (int i = 0; i < array.length; i++) {
	        for (int j = 0; j < array.length; j++) {
	            if (array[i] <= array[j]) {
	                int x = array[i];
	                array[i] = array[j];
	                array[j] = x;
	            }
	        }
	    }
	    return array;
	}
	
	private static Integer[] sortArrayAlgorithmDesc(Integer[] array) 
	{ 
	    for (int i = 0; i < array.length; i++) {
	        for (int j = 0; j < array.length; j++) {
	            if (array[i] >= array[j]) {
	                int x = array[i];
	                array[i] = array[j];
	                array[j] = x;
	            }
	        }
	    }
	    return array;
	}
}
