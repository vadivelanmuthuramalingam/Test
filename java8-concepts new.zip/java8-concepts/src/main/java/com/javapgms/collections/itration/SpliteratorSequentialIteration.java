package com.javapgms.collections.itration;

/*
 * 
 * 
 * 
 
 Like Iterator and ListIterator, Spliterator is a Java Iterator, which is used to iterate elements one-by-one from a List implemented 
 object.

Some important points about Java Spliterator are:
	Java Spliterator is an interface in Java Collection API.
	Spliterator is introduced in Java 8 release in java.util package.
	It supports Parallel Programming functionality.
	We can use it for both Collection API and Stream API classes.
	It provides characteristics about Collection or API objects.
	We can NOT use this Iterator for Map implemented classes.
	It uses tryAdvance() method to iterate elements individually in multiple Threads to support Parallel Processing.
	It uses forEachRemaining() method to iterate elements sequentially in a single Thread.
	It uses trySplit() method to divide itself into Sub-Spliterators to support Parallel Processing.
	Spliterator supports both Sequential and Parallel processing of data.


Spliterator itself does not provide the parallel programming behavior. However, it provides some methods to support it. 
Developers should utilize Spliterator interface methods and implement parallel programming by using Fork/Join Framework (one good approach).

Main Functionalities of Spliterator
	Splitting the source data.
	Processing the source data.
 
 * 
 * 
 * 
 * 
 * 
 */
import java.util.Spliterator;
import java.util.ArrayList;
import java.util.List;

public class SpliteratorSequentialIteration
{
  public static void main(String[] args) 
  {
	List<String> names = new ArrayList<>();
	names.add("Rams");
	names.add("Posa");
	names.add("Chinni");
	names.add("data1");
	names.add("data2");
	names.add("data3");
	names.add("data4");
	names.add("data5");
	names.add("data6");
	names.add("data7");
	names.add("data8");
	names.add("data9");
	names.add("data10");
	
	// Getting Spliterator
	Spliterator<String> namesSpliterator = names.spliterator();
		
	// Traversing elements
	namesSpliterator.forEachRemaining(System.out::println);	
	
   }
}

