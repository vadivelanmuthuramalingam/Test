package com.javapgms.collections.hashmaps;

import java.util.Hashtable;

public class HashTable_01 
{

	public static void main(String []args)
	{
		Hashtable<String, String> ht = new Hashtable<>();
		ht.put("name1", "Name 1");
		
	}
}
