package com.javapgms.collections.hashmaps;

import java.util.HashMap;
import java.util.Map;

public class Test_02 
{

	public static void main(String[] args)
	{
		Employee emp1 = new Employee(1, "Vadivelan");
		Employee emp2 = new Employee(1, "Karthik");
		Employee emp3 = new Employee(1, "Karthik 1");
		Employee emp4 = new Employee(1, "Vadivelan");
		Employee emp5 = new Employee(2, "Vadivelan");
		
		System.out.println("---------------Sceanarion 1--------------------");
		Map<Employee, Integer> map = new HashMap<>();
		
		map.put(emp1, 1);
		map.put(emp2, 1);
		map.put(emp3, 1);
		map.put(emp4, 1);
		map.put(emp5, 2);
		
		//System.out.println(map);

		map.forEach((k,v) -> System.out.println("Key = " + k + " Value = "+ String.valueOf(v)) ); 
		
		System.out.println("---------------Sceanarion 2--------------------");
		Map<String, Employee> map2 = new HashMap<>();
		
		map2.put(emp1.getName(), emp1);
		map2.put(emp2.getName(), emp2);
		map2.put(emp3.getName(), emp3);
		map2.put(emp4.getName(), emp4);
		map2.put(emp5.getName(), emp5);

		map2.forEach((k,v) -> System.out.println("Key = " + k + " Value = "+ String.valueOf(v)) ); 
	}
}


class Employee
{
	private int id;
	private String name;
	
	
	
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public int hashCode()
	{
		return this.id;
	}

	
}