package com.javapgms.collections;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Comparable_Comparator_Test 
{

	public static void main(String[] args)
	{
		List<Employees> emp = Arrays.asList(new Employees(1, "Vadivelan", 10000),
				new Employees(5, "Senthil", 5000),
				new Employees(2, "Muthu", 2000),
				new Employees(4, "Velan", 4000),
				new Employees(3, "Vadivelan", 30000),
				new Employees(6, "Paddu", 6000),
				new Employees(8, "karthik", 8000),
				new Employees(7, "Mohan", 7000));
		
		Collections.sort(emp);
		emp.stream().forEach(x -> System.out.println("Id : " + x.getId() + " Name: "+ x.getName() + " Salary: "+ x.getSalary()));

		
		 emp = Arrays.asList(new Employees(1, "Vadivelan", 10000),
					new Employees(5, "Senthil", 5000),
					new Employees(2, "Muthu", 2000),
					new Employees(4, "Velan", 4000),
					new Employees(3, "Vadivelan", 30000),
					new Employees(6, "Paddu", 6000),
					new Employees(8, "karthik", 8000),
					new Employees(7, "Mohan", 7000));
		 
		Collections.sort(emp, new AmountComparator());
		emp.stream().forEach(x -> System.out.println("Id : " + x.getId() + " Name: "+ x.getName() + " Salary: "+ x.getSalary()));

	}
}


class Employees implements Comparable<Employees>
{
	private int id;
	private String name;
	private int salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Employees(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	@Override
	public int compareTo(Employees obj) {
		return this.id - obj.id;
	}
}

class AmountComparator implements Comparator<Employees>
{

	@Override
	public int compare(Employees o1, Employees o2) {
		// TODO Auto-generated method stub
		return o1.getSalary() - o2.getSalary();
	}
	
}