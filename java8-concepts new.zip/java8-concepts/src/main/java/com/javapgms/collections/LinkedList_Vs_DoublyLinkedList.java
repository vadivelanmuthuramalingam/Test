package com.javapgms.collections;

public class LinkedList_Vs_DoublyLinkedList 
{

	public static void main(String[] args)
	{
		
	}
}
