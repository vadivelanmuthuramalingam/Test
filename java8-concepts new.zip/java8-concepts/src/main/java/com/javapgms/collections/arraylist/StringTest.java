package com.javapgms.collections.arraylist;

public class StringTest 
{

	public static void main(String[] args)
	{
		String a = "hello";
		String b = "hello";
		String c = new String ("hello");
		String d = c;
		String e = new String("hello");
		
		System.out.println("a = b " + String.valueOf(a==b));
		System.out.println("a .eq b " + a.equals(b));
		
		System.out.println("c = d " + String.valueOf(c==d));
		System.out.println("c .eq d " + c.equals(c));
		
		
		System.out.println("c = e " + String.valueOf(c==e));
		System.out.println("c .eq e " + c.equals(e));
		
		System.out.println("d = e " + String.valueOf(d==e));
		System.out.println("d .eq e " + d.equals(e));
		
	}
}
