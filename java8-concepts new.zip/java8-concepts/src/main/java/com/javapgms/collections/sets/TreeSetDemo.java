package com.javapgms.collections.sets;

import java.util.TreeSet;

public class TreeSetDemo 
{

	 public static void main(String[] args) 
	 {
	     // Create a TreeSet
	     TreeSet<String> tset = new TreeSet<String>();
	 
	     //add elements to TreeSet
	     tset.add("Abhijeet");
	     tset.add("Ram");
	     tset.add("Kevin");
	     tset.add("Singh");
	     tset.add("Rick");
	     // Duplicate removed
	     tset.add("Ram"); 
	  
	    
	     // Displaying TreeSet elements
	     System.out.println("TreeSet contains: ");
	     for(String temp : tset){
	        System.out.println(temp);
	     }
	     
	     String lastValue = tset.pollLast();

	     System.out.println("TreeSet contains --> 1: ");
	     for(String temp : tset){
	        System.out.println(temp);
	     }
	     
	     
	     String secondndLastValue = tset.pollLast();

	     System.out.println("TreeSet contains --> 2: ");
	     for(String temp : tset){
	        System.out.println(temp);
	     }
	     
	  }
}
