package com.javapgms.collections.hashmaps;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMap_03 
{

	public static void main(String[] args)
	{
		HashMap<String, String> hm = new HashMap();
		hm.put("name1", "name 1");
		hm.put("name2", "name 2");
		hm.put("name3", "name 3");
		hm.put("name4", "name 4");
		hm.put("name5", "name 5");
		hm.put("name6", "name 6");
		hm.put("name7", "name 7");
		
		//Iterator<HashMap<String, String>> hmit = hm.it
		Iterator it = hm.entrySet().iterator();
		
		while(it.hasNext())
		{
			Map.Entry pair = (Map.Entry)it.next();
	        System.out.println(pair.getKey() + " = " + pair.getValue());
		}
		
		
		Iterator it1 = hm.entrySet().iterator(); //getting java.util.ConcurrentModificationException used conncurrent hashmap to avoid this issue.
		
		//refer 4th example to avoid the issue
		while(it1.hasNext())
		{
			Map.Entry pair = (Map.Entry)it1.next();
	        System.out.println(pair.getKey() + " = " + pair.getValue());
	        
	        hm.remove("name5");
		}
	}
}
