package com.javapgms.collections;

import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayList_Vs_LinkedList 
{
	public static void main(String[] args)
	{
	
		ArrayList<String> al = new ArrayList<>(); //initally start with Element size as 10
		for(int i=0;i<5;i++)
		{
			al.add(String.valueOf(i)); //when 10 reach another 5 is created . when 15 reached another  7 is created Formula 1.5 times of original array
			
			//Class Hierarchy public class ArrayList<E> extends AbstractList<E> implements List<E>, RandomAccess, Cloneable, java.io.Serializable
		}
		
		al.add(2, "testvalue");
		
		LinkedList<String> list = new LinkedList<>();
		for(int i=0;i<5;i++)
		{
			list.add(String.valueOf(i));
		}
		
		list.remove(2);
		list.push("6");
		list.add(2, "test value");
		String test = list.peek(); //get the first node value from linked list.
		test=list.pop(); //get the first element and remove the value from linked list
		System.out.println(al);
	}
}
