package com.javapgms.collections.itration;


/*
 * 
ListIterator is an interface in Collection API. It extends Iterator interface. 
To support Forward and Backward Direction iteration and CRUD operations, it has the following methods. 
We can use this Iterator for all List implemented classes like ArrayList, CopyOnWriteArrayList, LinkedList, Stack, Vector etc.





Java ListIterator Methods
Java ListIterator interface has the following Methods.

	void add(E e): 	Inserts the specified element into the list.
	boolean hasNext(): Returns true if this list iterator has more elements when traversing the list in the forward direction.
	boolean hasPrevious(): Returns true if this list iterator has more elements when traversing the list in the reverse direction.
	E next(): Returns the next element in the list and advances the cursor position.
	int nextIndex(): Returns the index of the element that would be returned by a subsequent call to next().
	E previous(): Returns the previous element in the list and moves the cursor position backwards.
	int previousIndex(): Returns the index of the element that would be returned by a subsequent call to previous().
	void remove(): Removes from the list the last element that was returned by next() or previous().
	void set(E e): Replaces the last element returned by next() or previous() with the specified element.



Limitations of ListIterator
	Compare to Iterator, Java ListIterator has many advantages. However, it still have the following some limitations.
	
	It is an Iterator only List implementation classes.
	Unlike Iterator, it is not applicable for whole Collection API.
	It is not a Universal Java Cursor.
	Compare to Spliterator, it does NOT support Parallel iteration of elements.
	Compare to Spliterator, it does NOT support better performance to iterate large volume of data.

Similarities between Iterator and ListIterator
	In this section, we will discuss about Similarities between Java two Cursors: Iterator and ListIterator.
	
	Bother are introduced in Java 1.2.
	Both are Iterators used to iterate Collection or List elements.
	Both supports READ and DELETE operations.
	Both supports Forward Direction iteration.
	Both are not Legacy interfaces.

Differences between Iterator and ListIterator
In this section, we sill discuss about differences between Java Two Iterators: Iterator and ListIterator.

ITERATOR											LISTITERATOR
-------------------------------------------------------------------------------------------------------------------------
Introduced in Java 1.2.							|	Introduced in Java 1.2.
It is an Iterator for whole Collection API.		|	It is an Iterator for only List implemented classes.
It is an Universal Iterator.					|	It is NOT an Universal Iterator.
It supports only Forward Direction Iteration.	|	It supports both Forward and Backward Direction iterations.
It’s a Uni-Directional Iterator.				|	It’s a Bi-Directional Iterator.
It supports only READ and DELETE operations.	|	It supports all CRUD operations.
We can get Iterator by using iterator() method.	|	We can ListIterator object using listIterator() method.

 */
import java.util.*;

public class ListIteratorDemo 
{
  public static void main(String[] args) 
  {
	List<String> names = new LinkedList<>();
	names.add("Rams");
	names.add("Posa");
	names.add("Chinni");
		
	// Getting ListIterator
	ListIterator<String> namesIterator = names.listIterator();
	
	// Traversing elements
	while(namesIterator.hasNext()){
	   System.out.println(namesIterator.next());			
	}	

	// Enhanced for loop creates Internal Iterator here.
	for(String name: names){
	   System.out.println(name);			
	}	
  }
}