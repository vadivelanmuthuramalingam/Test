package com.javapgms.collections.itration;

import java.util.*;

/*
 
Advantages of Java Iterator
	Compare to Enumeration interface, Java Iterator has the following advantages or benefits.
	
	We can use it for any Collection class.
	It supports both READ and REMOVE operations.
	It is an Universal Cursor for Collection API.
	Method names are simple and easy to use them.


Limitations of Java Iterator
	However, Java Iterator has the following limitations or drawbacks.
	
	In CRUD Operations, it does NOT support CREATE and UPDATE operations.
	It supports only Forward direction iteration that is Uni-Directional Iterator.
	Compare to Spliterator, it does NOT support iterating elements parallel that means it supports only Sequential iteration.
	Compare to Spliterator, it does NOT support better performance to iterate large volume of data.

	  
Differences between Java Enumeration and Iterator
The following table describes the differences between Java Enumeration and Iterator:

ENUMERATION												ITERATOR
-------------------------------------------------------------------------------------------------------------------
Introduced in Java 1.0								|	Introduced in Java 1.2
Legacy Interface									|	Not Legacy Interface
It is used to iterate only Legacy Collection classes|	We can use it for any Collection class.
It supports only READ operation.					|	It supports both READ and DELETE operations.
It’s not Universal Cursor.							|	Its a Universal Cursor.
Lengthy Method names.								|	Simple and easy to use method names.





Types of Java Iterators
As we know Java have four cursors: Enumeration, Iterator, ListIterator and Spliterator. We can categorize them into two main types as shown below:

Uni-Directional Iterators
	They are Cursors which supports only Forward Direction iterations. 
	For instance, Enumeration, Iterator etc. are Uni-Directional Iterators.

Bi-Directional Iterators
	They are Cursors which supports Both Forward Direction and Backward Direction iterations. 
	For instance, ListIterator are Uni-Directional Iterators.





 *
 *
 */
public class CustomClassItrator {

	public static void main(String[] args) {
		Employees emps = new Employees();
		for(Employee emp : emps){
			System.out.println(emp);
		}
	}
}


class Employees implements Iterable<Employee>
{

	private List<Employee> emps = null;
	
	public Employees(){
		emps = new ArrayList<>();
		emps.add(new Employee(1001,"Rams","Lead", 250000L));
		emps.add(new Employee(1002,"Posa","Dev", 150000L));
		emps.add(new Employee(1003,"Chinni","QA", 150000L));
	}
	
	@Override
	public Iterator<Employee> iterator() {
		return emps.iterator();
	}
}

class Employee {

	  private int empid;
	  private String ename;
	  private String designation;
	  private double salary;
		
	  public Employee(int empid,String ename,String designation,double salary){
		this.empid = empid;
		this.ename = ename;
		this.designation = designation;
		this.salary = salary;
	  }
		
	  public int getEmpid() {
		return empid;
	  }
		
	  public String getEname() {
		return ename;
	  }

	  public String getDesignation() {
		return designation;
	  }
		
	  public double getSalary() {
		return salary;
	  }	
		
	  @Override
	  public String toString(){
		return empid + "\t" + ename + "\t" + designation + "\t" + salary;	
	  }
		
	}