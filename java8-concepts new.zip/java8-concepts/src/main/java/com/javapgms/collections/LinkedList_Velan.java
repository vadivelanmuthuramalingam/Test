package com.javapgms.collections;

import java.util.LinkedList;

public class LinkedList_Velan 
{

	transient Node_V next = null;
	transient Node_V previous = null;
	transient Node_V head = null;
	transient Node_V tail = null;
	
	
	int size =0;
	public static void main(String[] args )
	{
		LinkedList<String> list = new LinkedList<>();
		list.add("data1");
		list.add("data2");
		list.add("data3");
		list.add("data4");
		list.add(3, "Intermediate Insert");
		//list.parallelStream();
		
		for(int i=0; i<list.size();i++)
			System.out.println("Add Address : "+ Integer.toHexString(list.get(i).hashCode()) +"  .  Data Variable Address : " + Integer.toHexString(list.get(i).hashCode()) + " Data: " + list.get(i));
			
		LinkedList_Velan llist = new LinkedList_Velan();
		
		llist.add("data1");
		llist.add("data2");
		llist.add("data3");
		llist.add("data4");
		llist.add("data5");
		
		
		Node_V testGet = llist.get(llist, 2);
		
		
		System.out.println(testGet.getData().toString());
	}
	
	public void add(String data)
	{
		Node_V currentNode = new Node_V(data);
		
		if(head == null)
			head = currentNode;
		else
		{
			if(head.next == null)
			{
				head.next = currentNode;
				currentNode.previous = head;
				currentNode.next = null;
				previous = currentNode;
				
			}
			else
			{
				previous.next = currentNode;
				currentNode.previous = previous;
				currentNode.next = null;
				previous = currentNode;
				
				
				
			}
		}
		
		
		tail = currentNode;
		//next = currentNode;
		size++;
		
		
		System.out.println("Add Address : "+ Integer.toHexString(currentNode.hashCode()) +"  .  Data Variable Address : " + Integer.toHexString(currentNode.getData().hashCode()) + " Data: " + currentNode.getData());
	}
	
	private Node_V get(LinkedList_Velan llist, int index)
	{
		System.out.println(this.size);
		Node_V node = llist.head;
		for(int i=0;i<size;i++)
		{
		
			System.out.print("Find Address : "+ Integer.toHexString(node.hashCode()) +"  .  Data Variable Address : " + Integer.toHexString(node.getData().hashCode()));
			System.out.println(Integer.toHexString(System.identityHashCode(node)) );

			if(i==index)
				return node;
			
			node = node.next;
		}
		
		return null;
	}
}

class Node_V
{
	Node_V next;
	Node_V previous;
	
	
	
	
	Object data = null;
	Node_V(String data)
	{
		this.data = data;
		
		next = null;
		previous = null;
	}
	
	public Object getData()
	{
		return this.data;
	}
}
