package com.javapgms.collections;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;



public class FilterDuplicateVadluesFromLsit 
{

	public static void main(String[] args)
	{
		List<StudentT> list = Arrays.asList(
				new StudentT(100, "Vadvivelan", "CSE"),
				new StudentT(102, "Muthuramalinga", "CSE"),
				new StudentT(100, "Vadvivelan", "CSE"),
				new StudentT(103, "Vadvivelan", "CSE"),
				new StudentT(104, "Senthil", "CSE"),
				new StudentT(105, "Vadvivelan", "CSE"),
				new StudentT(104, "Karthik", "CSE"));
		
		System.out.println("--------------Student Details Before Filter --------------------");
		list.stream().forEach(x -> System.out.println("ID : " + String.valueOf(x.getId()) +  " Name : " + String.valueOf(x.getName()) + " Dept : " + String.valueOf(x.getDept())));

		
		System.out.println("--------------Remove Duplicated baased on ID 1 --------------------");
		Set<StudentT> set=  list.stream().collect(
				Collectors.toCollection(
						() -> new TreeSet<StudentT>(Comparator.comparing(StudentT::getId))
						));
		set.forEach(x -> System.out.println("ID : " + String.valueOf(x.getId()) +  " Name : " + String.valueOf(x.getName()) + " Dept : " + String.valueOf(x.getDept())));
		
		
		/*System.out.println("--------------Remove Duplicated baased on List Remove IF --------------------");
		Set student = new HashSet<StudentT>();
		list.removeIf(std -> !student.add(std.getId()));
		list.forEach(x -> System.out.println("ID : " + String.valueOf(x.getId()) +  " Name : " + String.valueOf(x.getName()) + " Dept : " + String.valueOf(x.getDept())));
		*/
		
		System.out.println("--------------Remove Duplicated baased on ID --------------------");
		
		list.stream().distinct().collect(Collectors.toList()).forEach(x -> System.out.println("ID : " + String.valueOf(x.getId()) +  " Name : " + String.valueOf(x.getName()) + " Dept : " + String.valueOf(x.getDept())));
	}
}


class StudentT
{
	int id;
	String name;
	String dept;
	
	
	public StudentT(int id, String name, String dept) {
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	
	
}