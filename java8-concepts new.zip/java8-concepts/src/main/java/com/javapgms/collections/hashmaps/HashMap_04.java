package com.javapgms.collections.hashmaps;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class HashMap_04 
{

	public static void main(String[] args)
	{
		HashMap<String, String> hm = new HashMap();
		hm.put("name1", "name 1");
		hm.put("name2", "name 2");
		hm.put("name3", "name 3");
		hm.put("name4", "name 4");
		hm.put("name5", "name 5");
		hm.put("name6", "name 6");
		hm.put("name7", "name 7");
		
		//Iterator<HashMap<String, String>> hmit = hm.it
		Iterator it = hm.entrySet().iterator();
		
		while(it.hasNext())
		{
			Map.Entry pair = (Map.Entry)it.next();
	        System.out.println(pair.getKey() + " = " + pair.getValue());
		}
		
		
		System.out.println("\n\n\n");
		
		ConcurrentHashMap<String, String> cmap = new ConcurrentHashMap<>(hm);
		
		Iterator it1 = cmap.entrySet().iterator();
		
		while(it1.hasNext())
		{
			Map.Entry pair = (Map.Entry)it1.next();
	        System.out.println(pair.getKey() + " = " + pair.getValue());
	        cmap.remove("name3");
		}
	}
}
