package com.javapgms.collections;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayList_List_LinkedList 
{

	public static void main(String[] args)
	{
		String[] arr = null;
		//arr[0] = "data1"; ///getting array
		arr = new String[1];
		
		
		ArrayList<String> al = new ArrayList<>();
		al.add("data1");
		al.add("data2");
		al.add("data3");
		
		List<String> ls = new ArrayList<String>();
		ls.add("Data1");
		ls.add("Data2");
		ls.add("Data3");
		
		
		LinkedList<String> lls = new LinkedList<>();
		lls.add("Data1");
		lls.add("Data2");
		lls.add("Data3");
				
		System.out.println("************************************");
	}
}
