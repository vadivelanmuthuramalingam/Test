package com.javapgms.collections;

import java.util.HashMap;
import java.util.HashSet;

public class HashMap_Collision {

	public static void main(String[] args) 
	{
	
		
		HashMap<String, String> hm = new HashMap<>();
		hm.put("FB", "Lies String");
		hm.put("Ea","Foes Printed");
		hm.put("Ea","Foes Printed");
		
		
		
		int F = Integer.valueOf((char) 'F');
		int B = Integer.valueOf((char) 'B');
		int E = Integer.valueOf((char) 'E');
		int a = Integer.valueOf((char) 'a');
		
		System.out.println("F+B = "+ (F+B));
		System.out.println("E+a = "+ (E+a));
		
		System.out.println("F+B HashCode = "+ (F+B) % 30);
		System.out.println("E+a HashCode = "+ (E+a) % 30);
		System.out.println(Integer.valueOf((char) 'F'));
		System.out.println(Integer.valueOf((char) 'B'));
		System.out.println(Integer.valueOf((char) 'E'));
		System.out.println(Integer.valueOf((char) 'a'));
		System.out.println(hm.get("lies"));

		
		
		HashSet<String> hs = new HashSet<>();
		hs.add("Lies String");
		hs.add("Lies String");
		hs.add("Lies String");
		hs.add("Lies String");hs.add("Lies String");
		hs.add("Lies String");hs.add("Lies String");
		hs.add("Lies String");
		System.out.println(hs);
		System.out.println("has Set");
	}

}
