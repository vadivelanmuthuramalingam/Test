package com.javapgms.collections;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapExample 
{

public static void main(String[] args) {
		
		//Natural ordering of key Integer
		Map integerMap = new TreeMap();
		integerMap.put(5, "ABC");
		integerMap.put(1, "ABC");
		integerMap.put(2, "PQR");
		integerMap.put(3, "XXX");
		integerMap.put(4, "YYY");
		
		System.out.println(integerMap.toString());
		
		
	}
}
