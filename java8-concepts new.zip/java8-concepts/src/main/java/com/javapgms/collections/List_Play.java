package com.javapgms.collections;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class List_Play 
{

	public static void main(String[] args)
	{
		List<String> list = new ArrayList<>();
		
		list.add("Vadivelan");
		list.add("Muthuramalingam");
		list.add("Vadivelan");
		
		System.out.print("Print values what is available in the list : ");
		System.out.print(list);
		
		Set<String> set = new HashSet<>();
		set.add("Vadivelan 123");
		set.add("Vadivelan 123");
		set.add("Vadivelan 123");
		set.add("Vadivelan 123");
		
		set = list.stream().distinct().collect(Collectors.toSet());
		System.out.println(set);
		
		
		System.out.print("Print values and remove duplicate : ");
		list.stream().distinct().forEach(p -> System.out.println(p));
		
		
		System.out.print("Print values and remove duplicate Another Approach : ");
		
		
		list.stream().distinct().collect(Collectors.toList());
		System.out.println(list);
		
		list.add("Vadivelan");
		System.out.print("Print values and remove duplicate Another Approach by using map: ");
		list = list.stream().map(x -> x).distinct().collect(Collectors.toList());
		
		
		
		
		List<Integer> listWithDuplicates = Arrays.asList(1, 1, 2, 2, 3, 3);
	    List<Integer> listWithoutDuplicates = listWithDuplicates.stream().distinct().collect(Collectors.toList());
	    
	    
		System.out.println(listWithoutDuplicates);
		
	}
}
