package com.javapgms.collections.arraylist;

import java.util.ArrayList;
import java.util.List;

public class ArrayList_01 
{

	public static void main(String[] args)
	{
		
		int i=10;
		int k = i >> 1;
		
		System.out.println(k);
		
		System.out.print("List Max Size : "+ (Integer.MAX_VALUE - 8));
		
		ArrayList<String> al = new ArrayList<>();
		
		System.out.println(al.size());
		
		al = new ArrayList<>(2);
		System.out.println(al.size());
		
		al.add("test");
		al.add("test1");
		al.add("test2");
		al.add("test3");
		System.out.println(al.size());
		
		
		
	}
}
