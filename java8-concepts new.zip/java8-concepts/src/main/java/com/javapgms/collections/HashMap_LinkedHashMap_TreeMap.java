package com.javapgms.collections;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class HashMap_LinkedHashMap_TreeMap 
{

	public static void main(String[] args)
	{
		Map m1 = new HashMap();
		m1.put("map", "HashMap");
		m1.put("schildt", "java2");
		System.out.println(m1.keySet()); 
		System.out.println(m1.values()); 

		SortedMap sm = new TreeMap();
		sm.put("map", "TreeMap");
		sm.put("02", "02 Values");
		sm.put("schildt", "java2");
		sm.put("01", "01 Values");
		System.out.println(sm.keySet()); 
		System.out.println(sm.values());

		LinkedHashMap lm = new LinkedHashMap();
		lm.put("map", "LinkedHashMap");
		lm.put("02", "02 Values");
		lm.put("schildt", "java2");
		lm.put("01", "01 Values");
		
		System.out.println(lm.keySet()); 
		System.out.println(lm.values());
	}
}
