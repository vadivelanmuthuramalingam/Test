package com.javapgms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.javapgms.abstractsamples.ClassA;

import com.javapgms.interfaces.impl.ClassInterface1;
import com.javapgms.lampdaexpr.Test1;
import com.javapgms.staticclasess.StaticMethodTest;
import com.scm.seqnogeneration.GetNextReferenceNumber;
import com.scm.seqnogeneration.SeqNoGeneration;

@SpringBootApplication
public class Applicaiton {

	//@Autowired
	//private Interface1 interface1;
	
	
	@Autowired
	private GetNextReferenceNumber getNextReferenceNumber;
	
	public static void main(String[] args) 
	{
		SpringApplication.run(Applicaiton.class, args);
		//ClassA ClassA = new ClassA();  //Cannot create a instance/object for Abstract Class
		
		
		
		Test1 test= new Test1();
		test.printTest();
		/*
		StaticMethodTest obj = new StaticMethodTest();
		obj.print();
		obj.print();
		
		StaticMethodTest.printStatic();
		StaticMethodTest.printStatic();

		StaticMethodTest.printStatic2();
		StaticMethodTest.printStatic();
		
		obj.print();
		
		final int i;  
		   i = 20;  
		   
		   System.out.println(i);  
		
		System.out.println("test");
		*/
		
		System.out.println("test");
	}

}
