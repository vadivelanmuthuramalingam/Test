package com.javapgms.expeval;

import java.io.Serializable;
import java.util.HashMap;

public class HmTest implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> hmvalues = new HashMap<>();
	private String name;
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public HashMap<String, Object> getHmvalues() {
		return hmvalues;
	}

	public void setHmvalues(HashMap<String, Object> hmvalues) {
		this.hmvalues = hmvalues;
	}

			
	
	
}
