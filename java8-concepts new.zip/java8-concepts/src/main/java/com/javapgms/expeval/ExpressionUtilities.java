package com.javapgms.expeval;


import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class ExpressionUtilities 
{

	public static String testMethod()
	{
		return "sucessfully invoked external method.";
	}
	public static String lPad(String inputdata, String paddinCahr, int length)
	{
		if(inputdata == null) inputdata ="";
		String temp ="";
		if(inputdata.length() < length)
		{
				for (int x = 0; x <= length - inputdata.length() - 1; x++)
					temp += paddinCahr;
		
		}
		return temp.concat(inputdata);
	}
	public static String rPad(String inputdata, String paddinCahr, int length)
	{
		if(inputdata == null) inputdata ="";
		
		int itrationCount;
		String temp = "";
		if(inputdata.length() < length)
		{
			itrationCount =length - (inputdata.length() + 1);
			
			for (int x = 0; x <= itrationCount; x++) 
				temp += paddinCahr;
		}
		return inputdata.concat(temp);
	}
	public static String formateDate(final String input, final String format) 
	{
		
		String result ="";
		DateTimeFormatter oldPattern = null;
		DateTimeFormatter newPattern = null; 
		LocalDateTime datetime = null;
		try
		{
			
			oldPattern = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"); 
			newPattern = DateTimeFormatter.ofPattern(format); 
			datetime = LocalDateTime.parse(input, oldPattern); 
			result = datetime.format(newPattern);

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return result;
	}
	
	public static String now()
	{
		// represents Wed Feb 28 23:24:43 CET 2018
		Date now = new Date();

		// represents 2018-02-28T23:24:43.106
		LocalDateTime dateTime = LocalDateTime.ofInstant(now.toInstant(), ZoneId.systemDefault());

		// represent Wed Feb 28 23:24:43 CET 2018
		Date date = Date.from(dateTime.toInstant(ZoneOffset.ofHours(1)));
		//Date date = Date.from(dateTime.toInstant(ZoneId.systemDefault().getRules().getOffset(dateTime)));
		
		return String.valueOf(date);
	}
}
