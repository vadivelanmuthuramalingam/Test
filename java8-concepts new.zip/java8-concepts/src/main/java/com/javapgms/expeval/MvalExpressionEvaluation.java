package com.javapgms.expeval;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.mvel2.MVEL;
import org.mvel2.ParserContext;
import org.mvel2.integration.VariableResolverFactory;
import org.mvel2.integration.impl.MapVariableResolverFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.mvel2.MVEL.executeExpression;

public class MvalExpressionEvaluation 
{
	
	
	
	public static void main(String[] args) throws ParseException
	{
		
	    examples();
	    
	}
	
	public static HashMap<String, Object> clearAndAddValuesToHashMap(HashMap<String, Object> hmRoot)
	{
		hmRoot.clear();
		
		HmTest hmTest = new HmTest();
		HashMap<String, Object> hmValues = new HashMap<>();
		
		hmValues.put("name", "Vadivelan");
		hmValues.put("address1", "address 1");
		hmValues.put("address2", "address 2");
		hmValues.put("address3", "address's & 3");
		hmValues.put("dateofbirth", "2018-11-27");
		
		hmTest.setName("Vadivelan");
		hmTest. setHmvalues(hmValues); 
		
		
		hmRoot.put("hmtest", hmTest); //used in mval expression 
	    hmRoot.put("extObj", ExpressionUtilities.class);

		
		return hmRoot;
	}
	
	public static void examples() throws ParseException
	{

		String expression ="";
		
		
		HashMap<String, Object> hmRoot = new HashMap<>();
		
		
		hmRoot = clearAndAddValuesToHashMap(hmRoot);
		expression ="if(hmtest.name != null) {return hmtest.name ;} else { return \" name is not available \";}";
		execute(hmRoot, expression);

		//get value from hashmap
		hmRoot = clearAndAddValuesToHashMap(hmRoot);
		expression ="if(hmtest.hmvalues[\"dateofbirth\"] != null) {return hmtest.hmvalues[\"dateofbirth\"] ;}";
		execute(hmRoot, expression);

		
		
		//if else
		hmRoot = clearAndAddValuesToHashMap(hmRoot);
		expression ="if(hmtest.hmvalues[\"name1\"] != null) {return hmtest.hmvalues[\"name\"];} else { return \"Key Not Found.\";}";
	    execute(hmRoot, expression);
	    
	    //nested if else
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
		expression ="if(hmtest.hmvalues[\"name\"] != null && hmtest.hmvalues[\"address1\"] != null) {if(hmtest.hmvalues[\"name\"] == hmtest.hmvalues[\"address1\"] ) {\"Name and Address1 Value is Same\"} } else { return \"Name and Address1 value is differed.\";}";
	    execute(hmRoot, expression);

	    //for each
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression =  " String result =\"\"; for(String key : hmtest.hmvalues.keySet()) { result += hmtest.hmvalues[key] + \" \";} return result;";
	    execute(hmRoot, expression);
	 
	    //get value from list object
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    List<Integer> lst=new ArrayList<>();
		for(int i=0;i<10;i++)
		  lst.add(i);
		  
		hmRoot.put("baseroot",lst);
	
		  
		expression = " int sum = 0; foreach (x : baseroot) { sum += Integer.valueOf(x);} return sum;";
		execute(hmRoot, expression);

	    
	    //to find length
		hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression ="if(hmtest.hmvalues[\"name\"] != null) {return hmtest.hmvalues[\"name\"].length;} else { return \"\";}";
	    execute(hmRoot, expression);

	    //Substring values
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression ="if(hmtest.hmvalues[\"name\"] != null) {return hmtest.hmvalues[\"name\"].substring(0,5);} else { return \"\";}";
	    execute(hmRoot, expression);


	    //Formate date
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression = "import java.time.LocalDateTime; import java.time.format.DateTimeFormatter; String now = \"2016-11-09 10:30\";DateTimeFormatter formatter = DateTimeFormatter.ofPattern(\"yyyy-MM-dd HH:mm\");LocalDateTime formatDateTime = LocalDateTime.parse(now, formatter);";
	    execute(hmRoot, expression);
	    
	    expression = "import java.time.LocalDateTime; import java.time.format.DateTimeFormatter; "
	    		+ "String now = \"2016-11-09 10:30\";"
	    		+ "DateTimeFormatter formatter = DateTimeFormatter.ofPattern(\"yyyy-MM-dd HH:mm\");"
	    		+ "LocalDateTime formatDateTime = LocalDateTime.parse(now, formatter);"
	    		+ "formatDateTime.format(formatter);";
	    execute(hmRoot, expression);
	    

	    //String to local date
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    LocalDate localDate = null;
	    String date = "2016-10-11";
	    
	    localDate = LocalDate.parse(date);
	    System.out.println(String.valueOf(localDate));
	    expression = "import java.time.LocalDate; \r\n"
	    		+ "String date = hmtest.hmvalues[\"dateofbirth\"];"
	    		+ "//return hmtest.hmvalues[\"dateofbirth\"];\r\n"
	    		+ "LocalDate localDate = LocalDate.parse(date); "
	    		+ "return String.valueOf(localDate);";
	    execute(hmRoot, expression);
	    
	    expression = "return hmtest.hmvalues[\"dateofbirth\"]";
	    execute(hmRoot, expression);
	    
	    //formate date time
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression ="import java.time.LocalDate;import java.time.format.DateTimeFormatter;"
	    		+ "DateTimeFormatter formatter = DateTimeFormatter.ofPattern(\"d/MM/yyyy\");"
	    		+ "String date = \"16/08/2016\";"
	    		+ "LocalDate localDate = LocalDate.parse(date, formatter);"
	    		+ "System.out.println(localDate);"
	    		+ "return formatter.format(localDate);";
	    execute(hmRoot, expression);
	    
	    //invoke java method
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression = "String address3 = hmtest.hmvalues[\"address3\"].replaceAll(\"'\",\" \").replaceAll(\"&\",\" \"); "
	    		+ "return address3;";
	    execute(hmRoot, expression);
	    
	    //invoke external methods
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression = "return extObj.testMethod();";
	    execute(hmRoot, expression);

	    //LPAD.
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression = "return extObj.lPad(hmtest.hmvalues[\"address3\"],\"X\",20);";
	    execute(hmRoot, expression);

	    //RPAD.
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression = "return extObj.rPad(hmtest.hmvalues[\"address3\"],\"X\",20);";
	    execute(hmRoot, expression);
	    
	    
	    //invoke external methods in date format.
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression = "return extObj.now();";
	    execute(hmRoot, expression);
	    
	    
	  //invoke external methods in date format.
	    hmRoot = clearAndAddValuesToHashMap(hmRoot);
	    expression = "return now();";
	    execute(hmRoot, expression);
	}
	
	private static void execute(HashMap<String, Object> input, String expression)
	{
		MvalEngine.execute(input, expression);
		//ParserContext parserContext = new ParserContext();
		/*
		 *
		 * 
		 
		
		parserContext.addPackageImport("import java.util.Date");
		parserContext.addPackageImport("import java.text.SimpleDateFormat");
		parserContext.addPackageImport("import java.util.Map");
		parserContext.addPackageImport("import java.util.HashMap");
		parserContext.addPackageImport("import java.time.LocalDateTime");
		parserContext.addPackageImport("import java.time.format.DateTimeFormatter");
		
		
        for (Map.Entry<String, Object> entry : input.entrySet()) {
        	parserContext.addInput(entry.getKey(), entry.getValue().getClass());
        	//parserContext.addPackageImport(entry.getKey());
        	parserContext.addPackageImport("");
        	
        }
		*/
		
		
		/*
		VariableResolverFactory functionFactory = new MapVariableResolverFactory(input);
		Serializable compileExpression = MVEL.compileExpression(expression, parserContext);
	    Object result =  MVEL.executeExpression(compileExpression, input, functionFactory);
	    
	    System.out.println(String.valueOf(result));
	    */
	}
	
	
	
		public static void testJIRA208() {
	    Map<String, Object> vars = new LinkedHashMap<String, Object>();
	    vars.put("bal", 1000);

	    String[] testCases = {"bal - 80 - 90 - 30", "bal-80-90-30", "100 + 80 == 180", "100+80==180"};

	    //     System.out.println("bal = " + vars.get("bal"));

	    Object val1, val2;
	    for (String expr : testCases) {
	        System.out.print("Evaluating '" + expr + "': ");
	        val1 = MVEL.eval(expr, vars);

	        Serializable compiled = MVEL.compileExpression(expr);
	        val2 = executeExpression(compiled, vars);
	        
	        System.out.println(String.valueOf( val2));

	    }
	}
	
	
	
}

