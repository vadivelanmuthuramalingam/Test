package com.javapgms.expeval;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.mvel2.MVEL;
import org.mvel2.ParserContext;
import org.mvel2.integration.VariableResolverFactory;
import org.mvel2.integration.impl.MapVariableResolverFactory;

public class MvalEngine 
{

	public static Object execute(HashMap<String, Object> input, String expression)
	{
		expression = getExpression(expression);
		
		ParserContext parserContext = new ParserContext();
		
		//parserContext.addImport(ExpressionUtilities.class);
		

		/*
		 *
		 * 
		 
		
		parserContext.addPackageImport("import java.util.Date");
		parserContext.addPackageImport("import java.text.SimpleDateFormat");
		parserContext.addPackageImport("import java.util.Map");
		parserContext.addPackageImport("import java.util.HashMap");
		parserContext.addPackageImport("import java.time.LocalDateTime");
		parserContext.addPackageImport("import java.time.format.DateTimeFormatter");
		
		
        for (Map.Entry<String, Object> entry : input.entrySet()) {
        	parserContext.addInput(entry.getKey(), entry.getValue().getClass());
        	//parserContext.addPackageImport(entry.getKey());
        	parserContext.addPackageImport("");
        	
        }
		*/
		VariableResolverFactory functionFactory = new MapVariableResolverFactory(input);
		Serializable compileExpression = MVEL.compileExpression(expression, parserContext);
	    Object result =  MVEL.executeExpression(compileExpression, input, functionFactory);
	    
	    System.out.println(String.valueOf(result));
	    
	    return result;
	}

	
	private static String getExpression(String expression)
	{
		Pattern p = Pattern.compile("((\\w+)\\s*\\()");
		Matcher m = p.matcher(expression);
		
		Set<String> functionSet = new HashSet<String>();
		while (m.find()) {
			functionSet.add(m.group(2));
		}
		
		for (String s : functionSet) {
			switch (s) {

			case "formateDate":
				expression = expression.replaceAll("formateDate", "com.scm.expeval.ExpressionUtilities.formateDate");
				break;

			case "now":
				expression = expression.replaceAll("now", "com.scm.expeval.ExpressionUtilities.now");
				break;

			default:
				System.out.println(" no match");
			}
		}
		
		return expression;
	}
}
