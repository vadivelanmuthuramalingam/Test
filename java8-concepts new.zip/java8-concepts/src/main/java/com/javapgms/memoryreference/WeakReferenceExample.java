package com.javapgms.memoryreference;

import java.lang.ref.WeakReference;


public class WeakReferenceExample {
    public static void main(String[] args) {
        B b = new B();
        WeakReference<B> bRef = new WeakReference<B>(b);        
        C c = new C(b);
        A a = new A(c);
        b = null;
         
        System.out.println("Run gc");
        Runtime.getRuntime().gc();
         
        //a.finalize();
        System.out.println("bRef's referent:" + bRef.get());
        System.out.println("bRef's referent thru a->c->d->bRef:" + a.getC().getD().getB());
    }
  
}

class A {
    private C c;
     
    public A(C c) {
        this.c = c;
    }
     
    public C getC() {
        return c;
    }
     
    @Override
    public void finalize() {
        System.out.println("A cleaned");
    }
}

class B {
	 
    @Override
    public void finalize() {
        System.out.println("B cleaned");
    }
}

class C {
    private D d;
 
    public C(B b) {
        d = new D(new WeakReference<B>(b));    
    }
 
    public D getD() {
        return d;
    }
     
    @Override
    public void finalize() {
        System.out.println("C cleaned");
    }
}

class D 
{
	private WeakReference<B> bRef;
	
	public D(WeakReference<B>bRef) {
	    this.bRef = bRef;
	}
	 
	public B getB() {
	    return bRef.get();
	}
	 
	@Override
	public void finalize() {
	    System.out.println("D cleaned");
	}
}
