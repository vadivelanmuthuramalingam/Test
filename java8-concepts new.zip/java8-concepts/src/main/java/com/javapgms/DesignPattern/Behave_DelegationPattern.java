package com.javapgms.DesignPattern;

public class Behave_DelegationPattern 
{

	public static void main(String args[]) {
        Cat c = new Cat();
        // Delegation
        c.makeSound();          // Output: Meow
        // now to change the sound it makes
        ISoundBehaviour newsound = new RoarSound();
        c.setSoundBehaviour(newsound);
        // Delegation           
        c.makeSound();          // Output: Roar!
	}
}


interface ISoundBehaviour {
    
    public void makeSound();
}

class MeowSound implements ISoundBehaviour {

    public void makeSound() {
            System.out.println("Meow");
    }
}

class RoarSound implements ISoundBehaviour {

    public void makeSound() {
            System.out.println("Roar!");
    }
}

class Cat {  
	  private ISoundBehaviour sound = new MeowSound();  

	  public void makeSound() {  
	    this.sound.makeSound();  
	  }  

	  public void setSoundBehaviour(ISoundBehaviour newsound) {  
	        this.sound = newsound;  
	  }  
	}