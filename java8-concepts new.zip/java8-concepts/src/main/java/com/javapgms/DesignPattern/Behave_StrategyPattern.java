package com.javapgms.DesignPattern;

public class Behave_StrategyPattern {

	public static void main(String args[]) 
    { 
        // let us make some behaviors first 
        JumpBehavior shortJump = new ShortJump(); 
        JumpBehavior LongJump = new LongJump(); 
        KickBehavior tornadoKick = new TornadoKick(); 
  
        // Make a fighter with desired behaviors 
        Fighter ken = new Ken(tornadoKick,shortJump); 
        ken.display(); 
  
        // Test behaviors 
        ken.punch(); 
        ken.kick(); 
        ken.jump(); 
  
        // Change behavior dynamically (algorithms are 
        // interchangeable) 
        ken.setJumpBehavior(LongJump); 
        ken.jump(); 
    } 
}


//Java program to demonstrate implementation of 
//Strategy Pattern 

//Abstract as you must have a specific fighter 
abstract class Fighter 
{ 
 KickBehavior kickBehavior; 
 JumpBehavior jumpBehavior; 

 public Fighter(KickBehavior kickBehavior, 
                JumpBehavior jumpBehavior) 
 { 
     this.jumpBehavior = jumpBehavior; 
     this.kickBehavior = kickBehavior; 
 } 
 public void punch() 
 { 
     System.out.println("Default Punch"); 
 } 
 public void kick() 
 { 
     // delegate to kick behavior 
     kickBehavior.kick(); 
 } 
 public void jump() 
 { 

     // delegate to jump behavior 
     jumpBehavior.jump(); 
 } 
 public void roll() 
 { 
     System.out.println("Default Roll"); 
 } 
 public void setKickBehavior(KickBehavior kickBehavior) 
 { 
     this.kickBehavior = kickBehavior; 
 } 
 public void setJumpBehavior(JumpBehavior jumpBehavior) 
 { 
     this.jumpBehavior = jumpBehavior; 
 } 
 public abstract void display(); 
} 

//Encapsulated kick behaviors 
interface KickBehavior 
{ 
 public void kick(); 
} 
class LightningKick implements KickBehavior 
{ 
 public void kick() 
 { 
     System.out.println("Lightning Kick"); 
 } 
} 
class TornadoKick implements KickBehavior 
{ 
 public void kick() 
 { 
     System.out.println("Tornado Kick"); 
 } 
} 

//Encapsulated jump behaviors 
interface JumpBehavior 
{ 
 public void jump(); 
} 
class ShortJump implements JumpBehavior 
{ 
 public void jump() 
 { 
     System.out.println("Short Jump"); 
 } 
} 
class LongJump implements JumpBehavior 
{ 
 public void jump() 
 { 
     System.out.println("Long Jump"); 
 } 
} 

//Characters 
class Ryu extends Fighter 
{ 
 public Ryu(KickBehavior kickBehavior, 
            JumpBehavior jumpBehavior) 
 { 
     super(kickBehavior,jumpBehavior); 
 } 
 public void display() 
 { 
     System.out.println("Ryu"); 
 } 
} 
class Ken extends Fighter 
{ 
 public Ken(KickBehavior kickBehavior, 
            JumpBehavior jumpBehavior) 
 { 
     super(kickBehavior,jumpBehavior); 
 } 
 public void display() 
 { 
     System.out.println("Ken"); 
 } 
} 
class ChunLi extends Fighter 
{ 
 public ChunLi(KickBehavior kickBehavior, 
               JumpBehavior jumpBehavior) 
 { 
     super(kickBehavior,jumpBehavior); 
 } 
 public void display() 
 { 
     System.out.println("ChunLi"); 
 } 
}