package com.javapgms.DesignPattern;


//refer http://best-practice-software-engineering.ifs.tuwien.ac.at/patterns/factory.html
public class Creational_Factory 
{
	 public static void main(String args[]) {

		
	        // At first we create a shopping-cart
	        Product[] cart = new Product[3];

	        // Shopping!
	        cart[0] = ProductFactory.createProduct("Milk");
	        cart[1] = ProductFactory.createProduct("Sugar");
	        cart[2] = ProductFactory.createProduct("Bread");
	        
	        System.out.println(cart[2].getProductType());
	    }
}


class ProductFactory {

    public static Product createProduct(String what) {

        // When sugar is requested, we return sugar:
        if (what.equals("Sugar")) {
            return new Sugar(1.49F);
        }
        // When milk is needed, we return milk:
        else if (what.equals("Milk")) {
            return new Milk(0.99F);
        }
        // If the requested Product is not available, 
        //   we produce Milk for a special price.
        else {
        	return new Product() {
				
				@Override
				public float getPrice() {
					// TODO Auto-generated method stub
					return 0;
				}
			};
            //return new Milk(0.79F);
        }
    }
}

abstract class Product {

    public abstract float getPrice();

    public String getProductType() {
        return "Unknown Product";
    }

}

class Milk extends Product {

    private float price;

    protected Milk(float price) {
        this.price = price;
    }

    public float getPrice() {
        return price;
    }

    public String getProductType() {
        return "Milk";
    }

}


class Sugar extends Product {

    private float price;

    protected Sugar(float price) {
        this.price = price;
    }

    public float getPrice() {
        return price;
    }

    public String getProductType() {
        return "Sugar";
    }

}


