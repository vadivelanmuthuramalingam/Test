package com.javapgms.DesignPattern;

/*
 * 
 * 
 * Now Let’s try and understand the facade pattern better using a simple example. 
 * Let’s consider a hotel. This hotel has a hotel keeper. There are a lot of restaurants inside hotel e.g. Veg restaurants, 
 * Non-Veg restaurants and Veg/Non Both restaurants.You, as client want access to different menus of different restaurants . 
 * You do not know what are the different menus they have. You just have access to hotel keeper who knows his hotel well. 
 * Whichever menu you want, you tell the hotel keeper and he takes it out of from the respective restaurants and hands it over 
 * to you. Here, the hotel keeper acts as the facade, as he hides the complexities of the system hotel.
 */
public class Struct_Facade 
{

	public static void main (String[] args) 
    { 
        HotelKeeper keeper = new HotelKeeper(); 
          
        VegMenu v = keeper.getVegMenu(); 
        NonVegMenu nv = keeper.getNonVegMenu(); 
        Both both= keeper.getVegNonMenu(); 
  
    } 
}

class NonVegMenu implements Menus
{

	@Override
	public Menus getMenu() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
class VegMenu implements Menus
{

	@Override
	public Menus getMenu() {
		System.out.println("vegmenu class called..");
		return null;
	}
	
}
class Both implements Menus
{

	@Override
	public Menus getMenu() {
		// TODO Auto-generated method stub
		return null;
	}
	
}

interface Menus
{
	public Menus getMenu();
}

interface Hotel 
{ 
    public Menus getMenus(); 
} 

class NonVegRestaurant implements Hotel 
{ 
    public Menus getMenus() 
    { 
        NonVegMenu nv = new NonVegMenu(); 
        return nv; 
    } 
} 

class VegRestaurant implements Hotel 
{ 
    public Menus getMenus() 
    { 
        VegMenu v = new VegMenu(); 
        return v; 
    } 
} 

class VegNonBothRestaurant implements Hotel 
{ 
    public Menus getMenus() 
    { 
        Both b = new Both(); 
        return b; 
    } 
} 

class HotelKeeper 
{ 
    public VegMenu getVegMenu() 
    { 
        VegRestaurant v = new VegRestaurant(); 
        VegMenu vegMenu = (VegMenu) v.getMenus(); 
        return vegMenu; 
    } 
      
    public NonVegMenu getNonVegMenu() 
    { 
        NonVegRestaurant v = new NonVegRestaurant(); 
        NonVegMenu NonvegMenu = (NonVegMenu)v.getMenus(); 
        return NonvegMenu; 
    } 
      
    public Both getVegNonMenu() 
    { 
        VegNonBothRestaurant v = new VegNonBothRestaurant(); 
        Both bothMenu = (Both)v.getMenus(); 
        return bothMenu; 
    }     
} 