package com.javapgms.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;


public class Predicate_Example 
{

	public static void main(String[] args)
	{
		
		List<Employee> list = Arrays.asList(new Employee(10, "vadivelan", 35), 
				new Employee(11, "Karthik", 26), 
				new Employee(13, "Senthil", 40),
				new Employee(14, "Paddu", 42));
		
		//example 1
		System.out.println("-------------------------Example 1------------------------------");
		List<Employee> list1 =  list.stream().filter(x -> x.getAge() >35).collect(Collectors.toList());
		
		list.stream().filter(x -> x.getAge() >35).collect(Collectors.toList()).forEach(x -> System.out.println(x.getName()));
		
		
		//example 2
		System.out.println("-------------------------Example 2------------------------------");
		
		Predicate<Employee> condAge = emp -> emp.getAge() > 35;
		Predicate<Employee> condName = emp -> emp.getName().startsWith("S") ;
		Predicate<Employee> cond= condAge.and(condName);
		
		list.stream().filter(cond).collect(Collectors.toList()).forEach(emp -> System.out.println(emp.getName()));
		
		//example 2
		System.out.println("-------------------------Example 3 Conumer------------------------------");
		
		Consumer<Employee> consumer = emp -> {System.out.print( "Id: " + String.valueOf(emp.getId()));
		System.out.println( "Name: " + emp.getName()); };
		
		list.stream().filter(emp -> emp.getName().length()>5 ).collect(Collectors.toList()).forEach(consumer);
		
	}
}


class Employee
{
	private int id;
	private String name;
	private int age;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	
	
		
}