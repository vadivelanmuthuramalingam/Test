package com.javapgms.abstractsamples;

class CheckDefaultClass {

	public void print()
	{
		System.out.println("CheckDefaultClass -> Print");
	}
}
