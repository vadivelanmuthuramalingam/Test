package com.javapgms.abstractsamples;

//Cannot create a instance/object for Abstract Class
abstract class AbsClassA {

	public void printClassA()
	{
		System.out.println("Print");
	}
	
	public abstract String print();
}

class ClassB extends AbsClassA
{

	@Override
	public String print() {

		return "ClassB -> Print";
	}
	
}

public class ClassA
{
	public static void main(String[] args)
	{
		ClassB obj = new ClassB();
		System.out.println( obj.print());
		obj.print();
		obj.printClassA();
	}
}