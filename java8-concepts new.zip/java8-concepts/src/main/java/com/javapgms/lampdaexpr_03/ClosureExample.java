package com.javapgms.lampdaexpr_03;

import java.util.function.Predicate;

public class ClosureExample {

	public static void main(String[] args)
	{
		int a=10;
		int b = 30; //this is closure
		
		
		//JDK 7
		doProcess(a, new Process() {
			
			@Override
			public void process(int i) {
				System.out.println(i +b);
			}
		});
		
		
		//JDK 8
		
		doProcess(a, i -> System.out.println(i+b));
	}
	
	
	private static void doProcess(int i, Process process)
	{
		process.process(i);
	}
}


interface Process
{
	void process(int i);
}