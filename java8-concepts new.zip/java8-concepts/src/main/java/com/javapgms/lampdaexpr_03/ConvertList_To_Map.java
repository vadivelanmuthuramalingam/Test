package com.javapgms.lampdaexpr_03;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ConvertList_To_Map {

	public static void main(String[] args)
	{
		//Convert List to Map and eliminate duplicate values
		List<Store> list = new ArrayList<>(); 
        list.add(new Store(1, "liquidweb.com")); 
        list.add(new Store(2, "linode.com")); 
        list.add(new Store(2, "linode.com")); 
        Map<Integer, String> result = list.stream().collect( 
                Collectors.toMap(Store::getNo, Store::getName,(oldValue, newValue) -> oldValue)); 
        System.out.println("Result 1 : " + result);

	}
}
class Store
{
	int no;
	String name;
	
	
	public Store(int no, String name) {
		super();
		this.no = no;
		this.name = name;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
