package com.javapgms.lampdaexpr_03;

import java.util.function.BiConsumer;

public class ExceptionHandlin {

	public static void main(String[] args) {
		int [] i = {1,2,3,4,5};
		int key = 2;
		
		process(i, key, (s,k) -> System.out.println(s + k));
		
		//getting exception when k=0
		//k=0;
		//process(i, key, (s,k) -> System.out.println(s/k));
		
		key=0;
		process(i, key, (s,k) ->  
			{
				try
				{
					System.out.println(s/k);
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			});
		
		//Another way to handle the exception
		process(i, key, wrapperProcess((v,k) -> System.out.println(v/k) ));
		
	}

	private static void process(int[] i, int key, BiConsumer<Integer, Integer> biConsumer)
	{
		for (int k : i)
		{
			biConsumer.accept(k, key);
		}
	}
	
	
	private static BiConsumer<Integer, Integer> wrapperProcess(BiConsumer<Integer, Integer> biConsumer)
	{
		
		return (v,k) -> {
			try
			{
				biConsumer.accept(v, k);
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			};
	}
}
